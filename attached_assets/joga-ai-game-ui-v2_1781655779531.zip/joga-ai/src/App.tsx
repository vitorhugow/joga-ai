import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BottomNavigation } from "@/components/BottomNavigation";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Perfil from "@/pages/Perfil";
import Comunidades from "@/pages/Comunidades";
import ComunidadePage from "@/pages/ComunidadePage";
import CriarPartida from "@/pages/CriarPartida";
import PreJogo from "@/pages/PreJogo";
import AoVivo from "@/pages/AoVivo";
import PosJogo from "@/pages/PosJogo";
import Jogos from "@/pages/Jogos";
import Premium from "@/pages/Premium";
import Campos from "@/pages/Campos";
import Ranking from "@/pages/Ranking";

const queryClient = new QueryClient();

const FULL_SCREEN_PATHS = ["/partida/100/ao-vivo"];

function Router() {
  return (
    <>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/perfil" component={Perfil} />
        <Route path="/comunidades" component={Comunidades} />
        <Route path="/comunidades/:id" component={ComunidadePage} />
        <Route path="/criar-partida" component={CriarPartida} />
        <Route path="/partida/:id/pre-jogo" component={PreJogo} />
        <Route path="/partida/:id/ao-vivo" component={AoVivo} />
        <Route path="/partida/:id/pos-jogo" component={PosJogo} />
        <Route path="/jogos" component={Jogos} />
        <Route path="/premium" component={Premium} />
        <Route path="/campos" component={Campos} />
        <Route path="/ranking" component={Ranking} />
        <Route component={NotFound} />
      </Switch>
      <BottomNavigation />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
