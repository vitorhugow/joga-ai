import { Link } from "wouter";
import { ChevronLeft, Bell, Zap } from "lucide-react";

interface AppHeaderProps {
  title?: string;
  showLogo?: boolean;
  showBack?: boolean;
  backUrl?: string;
  rightElement?: React.ReactNode;
  showBell?: boolean;
  dark?: boolean;
}

export function AppHeader({ title, showLogo, showBack, backUrl = "/", rightElement, showBell, dark }: AppHeaderProps) {
  const textColor = dark ? "text-white" : "text-slate-950";

  return (
    <header
      className={`sticky top-0 z-50 w-full px-4 pt-3 pb-2 ${dark ? "bg-transparent" : "bg-transparent"}`}
      data-testid="app-header"
    >
      <div
        className={`mx-auto max-w-md h-14 px-3 flex items-center justify-between rounded-2xl ${dark ? "border border-white/10 bg-black/18 backdrop-blur-xl" : "game-panel"}`}
      >
        <div className="flex items-center flex-1 min-w-0">
          {showBack && (
            <Link
              href={backUrl}
              className={`mr-2 w-10 h-10 -ml-1 rounded-xl flex items-center justify-center ${dark ? "bg-white/10 active:bg-white/15" : "bg-slate-100 active:bg-slate-200"} transition-colors`}
              data-testid="button-back"
            >
              <ChevronLeft className={`w-5 h-5 ${dark ? "text-white" : "text-slate-800"}`} />
            </Link>
          )}
          {showLogo ? (
            <div className="flex items-center gap-2 min-w-0">
              <div className="relative w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 via-green-700 to-slate-950 flex items-center justify-center shadow-lg shadow-emerald-900/20 overflow-hidden">
                <div className="absolute inset-0 grass-stripes opacity-40" />
                <Zap className="relative w-4 h-4 text-amber-300 fill-amber-300" />
              </div>
              <div className="leading-none">
                <span className="block font-display font-black text-xl text-slate-950 tracking-tight">Joga <span className="text-emerald-600">AI</span></span>
                <span className="block text-[9px] font-black uppercase tracking-[0.22em] text-slate-400 mt-1">Football app</span>
              </div>
            </div>
          ) : (
            <div className="min-w-0">
              <h1 className={`font-display font-black text-lg ${textColor} truncate tracking-tight uppercase`} data-testid="header-title">{title}</h1>
              {!dark && <div className="h-1 w-10 rounded-full bg-gradient-to-r from-emerald-500 to-amber-400 mt-0.5" />}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 pl-2">
          {showBell && (
            <button className={`relative w-10 h-10 rounded-xl flex items-center justify-center ${dark ? "bg-white/10" : "bg-slate-100"}`} data-testid="button-notifications">
              <Bell className={`w-4 h-4 ${dark ? "text-white" : "text-slate-700"}`} />
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500 border border-white" />
            </button>
          )}
          {rightElement && (
            <div className="flex items-center justify-end" data-testid="header-right-element">
              {rightElement}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
