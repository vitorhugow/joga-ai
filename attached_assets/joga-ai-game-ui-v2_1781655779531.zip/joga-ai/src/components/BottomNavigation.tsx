import { Link, useLocation } from "wouter";
import { Home, Calendar, Users, Trophy, User } from "lucide-react";

const navItems = [
  { path: "/", icon: Home, label: "Início" },
  { path: "/jogos", icon: Calendar, label: "Jogos" },
  { path: "/comunidades", icon: Users, label: "Equipas" },
  { path: "/ranking", icon: Trophy, label: "Ranking" },
  { path: "/perfil", icon: User, label: "Carta" },
];

export function BottomNavigation() {
  const [location] = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 safe-bottom px-3 pb-3 pointer-events-none" data-testid="bottom-navigation">
      <div
        className="max-w-md mx-auto grid grid-cols-5 gap-1.5 pointer-events-auto rounded-[1.65rem] px-2 py-2"
        style={{
          background: "linear-gradient(180deg, rgba(15,23,42,0.94), rgba(2,6,23,0.96))",
          backdropFilter: "blur(24px)",
          WebkitBackdropFilter: "blur(24px)",
          border: "1px solid rgba(255,255,255,0.12)",
          boxShadow: "0 -12px 34px rgba(15,23,42,0.22), inset 0 1px 0 rgba(255,255,255,0.12)",
        }}
      >
        {navItems.map((item) => {
          const isActive = location === item.path || (item.path !== "/" && location.startsWith(item.path));
          const Icon = item.icon;

          return (
            <Link key={item.path} href={item.path} className="relative flex flex-col items-center justify-center gap-1 rounded-2xl py-2 min-h-[54px] active:scale-95 transition-all" data-testid={`nav-${item.label.toLowerCase()}`}>
              {isActive && (
                <div className="absolute inset-0 rounded-2xl" style={{ background: "linear-gradient(135deg, rgba(34,197,94,0.95), rgba(13,148,136,0.88))", boxShadow: "0 10px 22px rgba(16,185,129,0.26), inset 0 1px 0 rgba(255,255,255,0.25)" }} />
              )}
              <Icon className="relative transition-all" style={{ width: 20, height: 20, color: isActive ? "#ffffff" : "#94a3b8", strokeWidth: isActive ? 2.6 : 1.9 }} />
              <span className="relative font-black uppercase tracking-wide transition-colors" style={{ fontSize: 9, color: isActive ? "#ffffff" : "#94a3b8" }}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
