import { Clock, Zap } from "lucide-react";

interface MatchEvent {
  id: string;
  type: string;
  player: string;
  time: string;
}

interface LiveMatchPanelProps {
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  matchTime: string;
  events: MatchEvent[];
  isRunning?: boolean;
}

const eventConfig: Record<string, { label: string; color: string; icon: string }> = {
  golo: { label: "Golo", color: "text-emerald-600", icon: "⚽" },
  assistencia: { label: "Assist.", color: "text-blue-600", icon: "🎯" },
  defesa: { label: "Defesa", color: "text-purple-600", icon: "🧤" },
  cartao_amarelo: { label: "Cartão", color: "text-amber-600", icon: "🟨" },
  cartao_vermelho: { label: "Cartão V.", color: "text-red-600", icon: "🟥" },
  falta: { label: "Falta", color: "text-orange-600", icon: "⚠️" },
};

export function LiveMatchPanel({ homeTeam, awayTeam, homeScore, awayScore, matchTime, events, isRunning }: LiveMatchPanelProps) {
  return (
    <div className="space-y-3" data-testid="live-match-panel">
      <div className="bg-gradient-to-br from-slate-800 to-slate-950 rounded-2xl overflow-hidden shadow-xl">
        {isRunning && (
          <div className="flex items-center justify-center gap-2 py-2 bg-red-600/90">
            <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <span className="text-white text-xs font-semibold uppercase tracking-widest">Ao Vivo</span>
          </div>
        )}
        <div className="px-4 py-5">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 text-center">
              <p className="font-display font-bold text-white text-sm uppercase tracking-wide leading-tight">{homeTeam}</p>
            </div>
            <div className="flex flex-col items-center gap-1 flex-shrink-0">
              <div className="flex items-center gap-2">
                <span className="font-display font-black text-5xl text-white leading-none">{homeScore}</span>
                <span className="text-white/40 text-3xl font-light">–</span>
                <span className="font-display font-black text-5xl text-white leading-none">{awayScore}</span>
              </div>
              <div className="flex items-center gap-1 mt-1">
                <Clock className="w-3 h-3 text-white/50" />
                <span className="font-display text-white/70 text-sm font-semibold">{matchTime}</span>
              </div>
            </div>
            <div className="flex-1 text-center">
              <p className="font-display font-bold text-white text-sm uppercase tracking-wide leading-tight">{awayTeam}</p>
            </div>
          </div>
        </div>
      </div>

      {events.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 py-2.5 border-b border-gray-50 flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Eventos</span>
          </div>
          <div className="divide-y divide-gray-50 max-h-48 overflow-y-auto">
            {events.map((event) => {
              const cfg = eventConfig[event.type] || { label: event.type, color: "text-gray-600", icon: "•" };
              return (
                <div key={event.id} className="px-4 py-2.5 flex items-center gap-3" data-testid={`event-${event.id}`}>
                  <span className="text-base">{cfg.icon}</span>
                  <div className="flex-1 min-w-0">
                    <span className={`text-xs font-semibold ${cfg.color}`}>{cfg.label}</span>
                    <span className="text-gray-700 text-sm ml-1.5 font-medium">{event.player}</span>
                  </div>
                  <span className="text-gray-400 text-xs font-display font-medium flex-shrink-0">{event.time}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
