import { MapPin, Clock, Users, Zap } from "lucide-react";
import { Link } from "wouter";

interface MatchCardProps {
  id: string;
  title: string;
  city: string;
  location: string;
  gameType: string;
  level: string;
  date: string;
  spotsRemaining: string;
  price?: string;
  isLotado?: boolean;
}

const gameTypeLabel: Record<string, string> = {
  futsal: "Futsal",
  fut5: "Fut 5",
  fut7: "Fut 7",
  futebol11: "Fut 11",
};

const levelColor: Record<string, string> = {
  recreativo: "bg-emerald-100 text-emerald-700",
  misto: "bg-blue-100 text-blue-700",
  competitivo: "bg-red-100 text-red-700",
};

const levelLabel: Record<string, string> = {
  recreativo: "Recreativo",
  misto: "Misto",
  competitivo: "Competitivo",
};

export function MatchCard({ id, title, city, location, gameType, level, date, spotsRemaining, price }: MatchCardProps) {
  const isLotado = spotsRemaining === "Lotado";

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-all duration-200 active:scale-[0.98]" data-testid={`match-card-${id}`}>
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex-1 min-w-0">
            <h3 className="font-display font-bold text-gray-900 text-base leading-tight truncate">{title}</h3>
            <div className="flex items-center gap-1.5 mt-1 text-gray-500 text-xs">
              <MapPin className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{location}, {city}</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            <span className="bg-gray-100 text-gray-700 text-xs font-semibold px-2 py-0.5 rounded-full">
              {gameTypeLabel[gameType] || gameType}
            </span>
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${levelColor[level] || "bg-gray-100 text-gray-700"}`}>
              {levelLabel[level] || level}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{date}</span>
            </div>
            {price && (
              <div className="flex items-center gap-1">
                <Zap className="w-3 h-3" />
                <span>{price}/jogador</span>
              </div>
            )}
          </div>
          <div className={`flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-full ${isLotado ? "bg-gray-100 text-gray-500" : "bg-primary text-white"}`} data-testid={`match-spots-${id}`}>
            <Users className="w-3 h-3" />
            <span>{spotsRemaining}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
