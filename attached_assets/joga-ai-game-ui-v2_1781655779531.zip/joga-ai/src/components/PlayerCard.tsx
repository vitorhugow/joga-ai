import { PlayerAttributes, calculateOverall } from "@/lib/cardUtils";

export type CardVariant = "default" | "premium";

interface PlayerCardProps {
  name: string;
  position: string;
  attributes: PlayerAttributes;
  shirtNumber: number;
  title: string;
  variant?: CardVariant;
  className?: string;
}

/* ════════════════════════════════════════════════════
   FOOTBALLER SILHOUETTE — dynamic shooting pose
   Side-view, right leg planted, left leg kicking
   ════════════════════════════════════════════════════ */
function FootballerSilhouette({ color = "rgba(255,255,255,0.92)", number }: { color?: string; number?: number }) {
  return (
    <svg viewBox="0 0 110 170" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full" aria-label="footballer">
      <defs>
        <filter id="fg-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="2.5" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="fg-shadow" x="-10%" y="-10%" width="130%" height="140%">
          <feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="rgba(0,0,0,0.5)" floodOpacity="0.6" />
        </filter>
      </defs>

      <g filter="url(#fg-shadow)">
        {/* ── HEAD ── */}
        <ellipse cx="70" cy="16" rx="13" ry="14" fill={color} />

        {/* ── HAIR / SKULL top ── */}
        <ellipse cx="70" cy="9" rx="10" ry="7" fill={color} opacity="0.6" />

        {/* ── NECK ── */}
        <path d="M64 28 L76 28 L75 36 L65 36Z" fill={color} />

        {/* ── TORSO — forward lean, athletic V-shape ── */}
        <path d="M40 40 Q46 35 70 36 Q84 37 88 44 L84 80 Q70 88 52 84 L40 68Z" fill={color} />

        {/* ── JERSEY NUMBER watermark (subtle) ── */}
        {number !== undefined && (
          <text
            x="65" y="68"
            textAnchor="middle"
            fontFamily="system-ui, sans-serif"
            fontWeight="900"
            fontSize="22"
            fill="rgba(0,0,0,0.18)"
            dominantBaseline="middle"
          >
            {number}
          </text>
        )}

        {/* ── LEFT ARM — raised forward high (balance) ── */}
        <path d="M42 46 Q28 38 18 28 Q13 22 17 17 Q22 13 28 18 Q38 28 44 42Z" fill={color} />
        {/* Forearm */}
        <ellipse cx="15" cy="15" rx="7" ry="4" transform="rotate(-30 15 15)" fill={color} opacity="0.85" />

        {/* ── RIGHT ARM — back for balance ── */}
        <path d="M86 48 Q98 44 104 56 Q107 64 101 67 Q95 68 90 58 Q86 52 86 50Z" fill={color} />

        {/* ── SUPPORT LEG (right) — planted straight ── */}
        <path d="M62 84 L66 118 L64 142 Q63 150 56 150 Q50 150 50 144 L54 118 L56 84Z" fill={color} />

        {/* ── KICKING THIGH (left) — raised forward ── */}
        <path d="M52 83 Q38 90 28 103 Q22 113 26 120 Q32 124 40 116 Q52 103 56 89Z" fill={color} />

        {/* ── LOWER KICKING LEG — shin going forward-down ── */}
        <path d="M26 118 Q16 128 12 140 Q13 148 22 146 Q32 142 38 130 Q34 122 28 116Z" fill={color} />

        {/* ── KICKING BOOT ── */}
        <path d="M12 140 Q2 143 2 150 Q7 156 18 152 Q28 148 30 140Z" fill={color} />

        {/* ── SUPPORT BOOT ── */}
        <ellipse cx="54" cy="151" rx="15" ry="6" fill={color} opacity="0.85" />
        <ellipse cx="42" cy="153" rx="8" ry="4" fill={color} opacity="0.6" />

        {/* ── BALL (at kicking foot) ── */}
        <circle cx="6" cy="153" r="10" stroke={color} strokeWidth="2" opacity="0.35" />
        <circle cx="6" cy="153" r="6" fill="none" stroke={color} strokeWidth="1.2" opacity="0.2" />

        {/* ── GROUND SHADOW ── */}
        <ellipse cx="50" cy="162" rx="32" ry="5" fill={color} opacity="0.1" />
      </g>
    </svg>
  );
}

/* ─── Portugal flag ─── */
function PortugalFlag() {
  return (
    <div style={{ display: "flex", width: 28, height: 18, borderRadius: 3, overflow: "hidden", boxShadow: "0 1px 5px rgba(0,0,0,0.5)", flexShrink: 0 }}>
      <div style={{ width: "38%", background: "#006600" }} />
      <div style={{ width: "62%", background: "#CC0000", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: "rgba(255,220,80,0.25)", border: "1.5px solid rgba(255,220,0,0.85)" }} />
      </div>
    </div>
  );
}

/* ─── Clip paths ─── */
const OCTA  = "polygon(8% 0%, 92% 0%, 100% 8%, 100% 92%, 92% 100%, 8% 100%, 0% 92%, 0% 8%)";
const SHIELD = "polygon(8% 0%, 92% 0%, 100% 8%, 100% 87%, 50% 100%, 0% 87%, 0% 8%)";

/* ════════════════════════════════════════════════════
   DEFAULT — Blue premium FIFA card
   ════════════════════════════════════════════════════ */
function DefaultCard({ name, position, attributes, shirtNumber, title }: PlayerCardProps) {
  const overall = calculateOverall(attributes);
  const firstName = name.split(" ")[0];
  const lastName  = name.split(" ").slice(1).join(" ") || firstName;

  return (
    <div
      className="relative w-full mx-auto select-none"
      style={{
        maxWidth: 300,
        aspectRatio: "0.72",
        filter: [
          "drop-shadow(0 0 18px rgba(59,130,246,0.90))",
          "drop-shadow(0 0 5px rgba(147,197,253,0.65))",
          "drop-shadow(0 8px 32px rgba(0,0,20,0.55))",
        ].join(" "),
      }}
      data-testid="player-card"
    >
      {/* ── Outer border: blue gradient ring ── */}
      <div className="absolute inset-0" style={{ clipPath: OCTA, background: "linear-gradient(145deg, #bfdbfe 0%, #3b82f6 25%, #1d4ed8 55%, #4f46e5 85%, #818cf8 100%)" }} />

      {/* ── White inner ring ── */}
      <div className="absolute inset-[3.5px]" style={{ clipPath: OCTA, background: "rgba(255,255,255,0.88)" }} />

      {/* ── Card body ── */}
      <div className="absolute inset-[6px] overflow-hidden" style={{ clipPath: OCTA }}>

        {/* Layer 1: Dark navy base */}
        <div className="absolute inset-0" style={{ background: "#050e1c" }} />

        {/* Layer 2: Warm diagonal burst (left, mimics España card) */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(128deg, #ff8c00 0%, #ff4400 10%, #ffbb00 17%, rgba(255,100,0,0.22) 38%, transparent 52%)" }} />

        {/* Layer 3: Warm radial glow top-left */}
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 12% 18%, rgba(255,170,0,0.5) 0%, transparent 42%)" }} />

        {/* Layer 4: Cool blue holographic right */}
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 90% 28%, rgba(120,190,255,0.80) 0%, rgba(40,120,255,0.45) 28%, transparent 58%)" }} />

        {/* Layer 5: Green stadium lights (top-right corner) */}
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 95% 5%, rgba(80,220,120,0.25) 0%, transparent 30%)" }} />

        {/* Layer 6: Halftone dots */}
        <div className="absolute inset-0" style={{
          backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.6) 1px, transparent 1px)",
          backgroundSize: "7px 7px",
          opacity: 0.22,
        }} />

        {/* Layer 7: Pitch lines watermark */}
        <div className="absolute inset-0" style={{
          backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 28px, rgba(255,255,255,0.04) 28px, rgba(255,255,255,0.04) 29px)",
          opacity: 1,
        }} />

        {/* Layer 8: Bottom dark vignette */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(2,5,20,0.88) 0%, rgba(2,5,20,0.4) 40%, transparent 68%)" }} />

        {/* ── Gold corner ornament lines ── */}
        {/* Top-left */}
        <div className="absolute" style={{ top: 4, left: 4, width: 14, height: 14 }}>
          <div style={{ position: "absolute", top: 0, left: 0, width: "100%", height: 1.5, background: "linear-gradient(90deg, #fbbf24, transparent)" }} />
          <div style={{ position: "absolute", top: 0, left: 0, width: 1.5, height: "100%", background: "linear-gradient(180deg, #fbbf24, transparent)" }} />
        </div>
        {/* Top-right */}
        <div className="absolute" style={{ top: 4, right: 4, width: 14, height: 14 }}>
          <div style={{ position: "absolute", top: 0, right: 0, width: "100%", height: 1.5, background: "linear-gradient(270deg, #fbbf24, transparent)" }} />
          <div style={{ position: "absolute", top: 0, right: 0, width: 1.5, height: "100%", background: "linear-gradient(180deg, #fbbf24, transparent)" }} />
        </div>
        {/* Bottom-left */}
        <div className="absolute" style={{ bottom: 4, left: 4, width: 14, height: 14 }}>
          <div style={{ position: "absolute", bottom: 0, left: 0, width: "100%", height: 1.5, background: "linear-gradient(90deg, #fbbf24, transparent)" }} />
          <div style={{ position: "absolute", bottom: 0, left: 0, width: 1.5, height: "100%", background: "linear-gradient(0deg, #fbbf24, transparent)" }} />
        </div>
        {/* Bottom-right */}
        <div className="absolute" style={{ bottom: 4, right: 4, width: 14, height: 14 }}>
          <div style={{ position: "absolute", bottom: 0, right: 0, width: "100%", height: 1.5, background: "linear-gradient(270deg, #fbbf24, transparent)" }} />
          <div style={{ position: "absolute", bottom: 0, right: 0, width: 1.5, height: "100%", background: "linear-gradient(0deg, #fbbf24, transparent)" }} />
        </div>

        {/* ── CONTENT ── */}
        <div className="relative h-full flex flex-col">

          {/* TOP: badge centered */}
          <div className="flex justify-center pt-2.5 flex-shrink-0">
            <div style={{
              width: 26, height: 26, borderRadius: "50%",
              background: "linear-gradient(135deg, rgba(255,255,255,0.22), rgba(255,255,255,0.06))",
              border: "1.5px solid rgba(255,255,255,0.38)",
              display: "flex", alignItems: "center", justifyContent: "center",
              backdropFilter: "blur(4px)",
            }}>
              <span style={{ fontSize: 12 }}>⚽</span>
            </div>
          </div>

          {/* OVR + POS + FLAG */}
          <div className="px-3 flex-shrink-0" style={{ marginTop: -2 }}>
            <div
              className="font-display font-black text-white leading-none"
              style={{ fontSize: "3.4rem", textShadow: "0 0 20px rgba(147,197,253,0.5), 0 2px 6px rgba(0,0,0,0.6)" }}
              data-testid="player-overall"
            >
              {overall}
            </div>
            <div className="font-display font-black text-white/65 tracking-[0.16em] leading-none" style={{ fontSize: "0.95rem", marginTop: 1 }}>
              {position}
            </div>
            <div style={{ marginTop: 6 }}>
              <PortugalFlag />
            </div>
          </div>

          {/* FOOTBALLER SILHOUETTE */}
          <div className="flex-1 flex items-end justify-center overflow-hidden" style={{ marginBottom: -10, paddingLeft: 8, paddingRight: 4 }}>
            <div style={{ width: "84%", height: "90%" }}>
              <FootballerSilhouette number={shirtNumber} />
            </div>
          </div>

          {/* PLAYER NAME */}
          <div className="flex-shrink-0 text-center px-3 pb-1" style={{ marginTop: 2 }}>
            <div className="font-display font-light text-white/35 uppercase" style={{ fontSize: "0.55rem", letterSpacing: "0.45em" }}>
              {firstName}
            </div>
            <div
              className="font-display font-black text-white uppercase leading-none"
              style={{ fontSize: "clamp(1.35rem, 7.5vw, 1.85rem)", letterSpacing: "-0.01em", textShadow: "0 2px 12px rgba(0,0,0,0.7)" }}
              data-testid="player-name"
            >
              {lastName}
            </div>
          </div>

          {/* DIVIDER with gold glow */}
          <div className="mx-4 flex-shrink-0" style={{ height: 1, background: "linear-gradient(90deg, transparent, rgba(251,191,36,0.5), rgba(255,255,255,0.3), rgba(251,191,36,0.5), transparent)", marginTop: 4, marginBottom: 5 }} />

          {/* ATTRIBUTES 3×2 */}
          <div className="grid grid-cols-2 flex-shrink-0 px-3.5 pb-2" style={{ gap: "3px 16px" }}>
            {[
              { l: "RIT", v: attributes.ritmo },
              { l: "DRI", v: attributes.drible },
              { l: "FIN", v: attributes.finalizacao },
              { l: "DEF", v: attributes.defesa },
              { l: "PAS", v: attributes.passe },
              { l: "FÍS", v: attributes.fisico },
            ].map(({ l, v }) => (
              <div key={l} className="flex items-baseline gap-1.5">
                <span className="font-display font-black text-white leading-none tabular-nums" style={{ fontSize: "1.2rem", textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}>{v}</span>
                <span className="font-display font-bold text-white/40 uppercase tracking-widest" style={{ fontSize: "0.55rem" }}>{l}</span>
              </div>
            ))}
          </div>

          {/* BRANDING */}
          <div className="text-center pb-2 flex-shrink-0">
            <span className="font-display font-bold uppercase tracking-[0.5em] text-white/12" style={{ fontSize: "0.4rem" }}>JOGA AI</span>
          </div>

        </div>
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════
   PREMIUM — Gold / marble card
   ════════════════════════════════════════════════════ */
function PremiumCard_({ name, position, attributes, shirtNumber, title }: PlayerCardProps) {
  const overall = calculateOverall(attributes);
  const firstName = name.split(" ")[0];
  const lastName  = name.split(" ").slice(1).join(" ") || firstName;

  return (
    <div
      className="relative w-full mx-auto select-none"
      style={{
        maxWidth: 300,
        aspectRatio: "0.72",
        filter: "drop-shadow(0 0 16px rgba(196,154,40,0.75)) drop-shadow(0 0 5px rgba(245,220,100,0.45)) drop-shadow(0 8px 28px rgba(0,0,0,0.5))",
      }}
      data-testid="player-card"
    >
      <div className="absolute inset-0" style={{ clipPath: SHIELD, background: "linear-gradient(145deg, #fef3c7 0%, #f59e0b 20%, #fbbf24 35%, #d97706 55%, #fef08a 70%, #b45309 100%)" }} />
      <div className="absolute inset-[3.5px]" style={{ clipPath: SHIELD, background: "rgba(255,255,255,0.92)" }} />

      <div className="absolute inset-[6px] overflow-hidden" style={{ clipPath: SHIELD }}>
        <div className="absolute inset-0" style={{ background: "linear-gradient(160deg, #f5f5f0 0%, #e8e8e0 50%, #d8d5cc 100%)" }} />
        <div className="absolute inset-0" style={{ backgroundImage: "repeating-linear-gradient(55deg, transparent, transparent 8px, rgba(0,0,0,0.04) 8px, rgba(0,0,0,0.04) 9px)" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(128deg, rgba(251,191,36,0.55) 0%, rgba(245,158,11,0.15) 35%, transparent 55%)" }} />
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 85% 25%, rgba(251,191,36,0.35) 0%, transparent 45%)" }} />
        <div className="absolute bottom-0 left-0 right-0" style={{ height: "40%", background: "linear-gradient(to top, rgba(195,190,180,0.7), transparent)" }} />

        {/* Gold corner ornaments */}
        {[
          { top: 4, left: 4 },
          { top: 4, right: 4 },
          { bottom: 4, left: 4 },
          { bottom: 4, right: 4 },
        ].map((pos, i) => (
          <div key={i} className="absolute" style={{ ...pos, width: 14, height: 14 }}>
            <div style={{ position: "absolute", top: pos.top !== undefined ? 0 : undefined, bottom: pos.bottom !== undefined ? 0 : undefined, left: pos.left !== undefined ? 0 : undefined, right: pos.right !== undefined ? 0 : undefined, width: "100%", height: 1.5, background: "linear-gradient(90deg, #b45309, transparent)" }} />
            <div style={{ position: "absolute", top: pos.top !== undefined ? 0 : undefined, bottom: pos.bottom !== undefined ? 0 : undefined, left: pos.left !== undefined ? 0 : undefined, right: pos.right !== undefined ? 0 : undefined, width: 1.5, height: "100%", background: "linear-gradient(180deg, #b45309, transparent)" }} />
          </div>
        ))}

        <div className="relative h-full flex flex-col">
          <div className="flex justify-center pt-2.5 flex-shrink-0">
            <div style={{ width: 26, height: 26, borderRadius: "50%", background: "linear-gradient(135deg, #fbbf24, #d97706)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 2px 8px rgba(0,0,0,0.2)" }}>
              <span style={{ color: "white", fontSize: 13, fontWeight: 900 }}>★</span>
            </div>
          </div>

          <div className="px-3 flex-shrink-0" style={{ marginTop: -2 }}>
            <div className="font-display font-black leading-none" style={{ fontSize: "3.4rem", color: "#7c2d12", textShadow: "0 1px 4px rgba(0,0,0,0.15)" }} data-testid="player-overall">{overall}</div>
            <div className="font-display font-black tracking-[0.16em] leading-none" style={{ fontSize: "0.95rem", color: "#92400e", marginTop: 1 }}>{position}</div>
            <div style={{ marginTop: 6 }}><PortugalFlag /></div>
          </div>

          <div className="flex-1 flex items-end justify-center overflow-hidden" style={{ marginBottom: -10, paddingLeft: 8, paddingRight: 4 }}>
            <div style={{ width: "84%", height: "90%" }}>
              <FootballerSilhouette color="rgba(120,80,20,0.45)" number={shirtNumber} />
            </div>
          </div>

          <div className="flex-shrink-0 text-center px-3 pb-1" style={{ marginTop: 2 }}>
            <div className="font-display font-light uppercase" style={{ fontSize: "0.55rem", letterSpacing: "0.45em", color: "#b45309" }}>{firstName}</div>
            <div className="font-display font-black uppercase leading-none" style={{ fontSize: "clamp(1.35rem, 7.5vw, 1.85rem)", color: "#1c0a00", letterSpacing: "-0.01em" }} data-testid="player-name">{lastName}</div>
            <div className="inline-block px-2 py-0.5 rounded mt-1 font-bold uppercase tracking-widest" style={{ background: "linear-gradient(135deg, #fbbf24, #d97706)", color: "#431407", fontSize: "0.5rem" }} data-testid="player-title">{title}</div>
          </div>

          <div className="mx-4 flex-shrink-0" style={{ height: 1, background: "linear-gradient(90deg, transparent, rgba(180,83,9,0.5), rgba(251,191,36,0.4), rgba(180,83,9,0.5), transparent)", marginTop: 4, marginBottom: 5 }} />

          <div className="grid grid-cols-2 flex-shrink-0 px-3.5 pb-2" style={{ gap: "3px 16px" }}>
            {[
              { l: "RIT", v: attributes.ritmo },
              { l: "DRI", v: attributes.drible },
              { l: "FIN", v: attributes.finalizacao },
              { l: "DEF", v: attributes.defesa },
              { l: "PAS", v: attributes.passe },
              { l: "FÍS", v: attributes.fisico },
            ].map(({ l, v }) => (
              <div key={l} className="flex items-baseline gap-1.5">
                <span className="font-display font-black leading-none tabular-nums" style={{ fontSize: "1.2rem", color: "#1c0a00" }}>{v}</span>
                <span className="font-display font-bold uppercase tracking-widest" style={{ fontSize: "0.55rem", color: "#b45309" }}>{l}</span>
              </div>
            ))}
          </div>

          <div className="text-center pb-2 flex-shrink-0">
            <span className="font-display font-bold uppercase tracking-[0.5em]" style={{ fontSize: "0.4rem", color: "rgba(180,83,9,0.35)" }}>PREMIUM</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export function PlayerCard(props: PlayerCardProps) {
  if (props.variant === "premium") return <PremiumCard_ {...props} />;
  return <DefaultCard {...props} />;
}
