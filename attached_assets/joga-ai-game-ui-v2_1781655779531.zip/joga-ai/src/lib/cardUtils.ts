export type PlayerAttributes = {
  ritmo: number;
  finalizacao: number;
  passe: number;
  defesa: number;
  drible: number;
  fisico: number;
};

export function calculateOverall(attributes: PlayerAttributes): number {
  const sum = Object.values(attributes).reduce((acc, val) => acc + val, 0);
  return Math.floor(sum / 6);
}

export function generateInitialAttributes(position: string): PlayerAttributes {
  // A simple stub for generating initial stats summing to ~330 (avg 55)
  // In a real app, logic would be position-based
  const base = 55;
  return {
    ritmo: base + Math.floor(Math.random() * 10) - 5,
    finalizacao: base + Math.floor(Math.random() * 10) - 5,
    passe: base + Math.floor(Math.random() * 10) - 5,
    defesa: base + Math.floor(Math.random() * 10) - 5,
    drible: base + Math.floor(Math.random() * 10) - 5,
    fisico: base + Math.floor(Math.random() * 10) - 5,
  };
}

export function applyMatchStatsToCard(currentAttrs: PlayerAttributes, matchPerformance: number): PlayerAttributes {
  // A simple stub for evolving attributes post-match
  return {
    ritmo: currentAttrs.ritmo + (matchPerformance > 8 ? 1 : 0),
    finalizacao: currentAttrs.finalizacao + (matchPerformance > 8 ? 1 : 0),
    passe: currentAttrs.passe + (matchPerformance > 8 ? 1 : 0),
    defesa: currentAttrs.defesa,
    drible: currentAttrs.drible + (matchPerformance > 8 ? 1 : 0),
    fisico: currentAttrs.fisico + (matchPerformance > 8 ? 1 : 0),
  };
}
