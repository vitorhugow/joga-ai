import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { StopCircle, Pause, Play } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { LiveMatchPanel } from "@/components/LiveMatchPanel";
import { VotacaoPendente } from "@/components/VotacaoPendente";
import { mockData } from "@/data/mockData";

type EventType = "golo" | "assistencia" | "defesa" | "cartao_amarelo" | "falta";

interface LiveEvent {
  id: string;
  type: EventType;
  player: string;
  team: "home" | "away";
  time: string;
}

const matchPlayers = [
  { id: "d1", name: "Diogo Ferreira", position: "AVA", team: "home" as const },
  { id: "p3", name: "Pedro Santos",   position: "MEI", team: "home" as const },
  { id: "b6", name: "Bruno Fernandes",position: "MEI", team: "home" as const },
  { id: "j2", name: "João Silva",     position: "DEF", team: "home" as const },
  { id: "m4", name: "Miguel Costa",   position: "GR",  team: "home" as const },
  { id: "r5", name: "Rui Patrício",   position: "AVA", team: "away" as const },
  { id: "a7", name: "André Lima",     position: "MEI", team: "away" as const },
  { id: "c8", name: "Carlos Sousa",   position: "DEF", team: "away" as const },
  { id: "n9", name: "Nuno Gomes",     position: "DEF", team: "away" as const },
  { id: "v10",name: "Vítor Silva",    position: "GR",  team: "away" as const },
];

const eventTypes: { key: EventType; label: string; emoji: string; bgColor: string; borderColor: string }[] = [
  { key: "golo",         label: "Golo",   emoji: "⚽", bgColor: "from-emerald-500 to-green-600",   borderColor: "#16a34a" },
  { key: "assistencia",  label: "Assist.",emoji: "🎯", bgColor: "from-blue-500 to-blue-600",       borderColor: "#2563eb" },
  { key: "defesa",       label: "Defesa", emoji: "🧤", bgColor: "from-purple-500 to-purple-600",   borderColor: "#7c3aed" },
  { key: "cartao_amarelo",label:"Cartão", emoji: "🟨", bgColor: "from-amber-400 to-amber-500",     borderColor: "#d97706" },
  { key: "falta",        label: "Falta",  emoji: "⚠️", bgColor: "from-red-500 to-red-600",         borderColor: "#dc2626" },
];

const posColors: Record<string, string> = {
  AVA: "bg-emerald-500",
  DEF: "bg-blue-500",
  MEI: "bg-purple-500",
  GR:  "bg-amber-500",
};

export default function AoVivo() {
  const [, setLocation] = useLocation();
  const liveMatch = mockData.liveMatches[0];
  const [homeScore, setHomeScore] = useState(liveMatch.score.home);
  const [awayScore, setAwayScore] = useState(liveMatch.score.away);
  const [isRunning, setIsRunning] = useState(true);
  const [seconds, setSeconds] = useState(42 * 60 + 15);
  const [events, setEvents] = useState<LiveEvent[]>(
    liveMatch.events.map((e) => ({ ...e, type: e.type as EventType, team: "home" as const }))
  );
  const [selectedPlayer, setSelectedPlayer] = useState<typeof matchPlayers[0]>(matchPlayers[0]);
  const [showVotacao, setShowVotacao] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const homePlayers = matchPlayers.filter((p) => p.team === "home");
  const awayPlayers = matchPlayers.filter((p) => p.team === "away");

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => setSeconds((s) => s + 1), 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRunning]);

  function formatTime(s: number) {
    const m = Math.floor(s / 60).toString().padStart(2, "0");
    const sec = (s % 60).toString().padStart(2, "0");
    return `${m}:${sec}`;
  }

  function addEvent(type: EventType) {
    if (!selectedPlayer) return;
    const mins = Math.floor(seconds / 60).toString().padStart(2, "0");
    const secs = (seconds % 60).toString().padStart(2, "0");
    const newEvent: LiveEvent = {
      id: `e${Date.now()}`,
      type,
      player: selectedPlayer.name,
      team: selectedPlayer.team,
      time: `${mins}:${secs}`,
    };
    setEvents((prev) => [newEvent, ...prev]);
    if (type === "golo") {
      if (selectedPlayer.team === "home") setHomeScore((s) => s + 1);
      else setAwayScore((s) => s + 1);
    }
  }

  function handleTerminar() {
    setIsRunning(false);
    setShowVotacao(true);
  }

  if (showVotacao) {
    return <VotacaoPendente onComplete={() => setLocation("/partida/100/pos-jogo")} />;
  }

  return (
    <div className="stadium-shell min-h-screen pb-28">
      <AppHeader title="Jogo ao Vivo" showBack backUrl="/partida/100/pre-jogo" />

      <div className="px-4 pt-4 space-y-4">
        {/* Scoreboard */}
        <LiveMatchPanel
          homeTeam="Os Leões"
          awayTeam="FC Baixa"
          homeScore={homeScore}
          awayScore={awayScore}
          matchTime={formatTime(seconds)}
          events={events}
          isRunning={isRunning}
        />

        {/* Timer Controls */}
        <div className="flex gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-display font-bold text-sm transition-all active:scale-[0.98] shadow-sm ${isRunning ? "bg-amber-500 text-white shadow-amber-200" : "bg-emerald-500 text-white shadow-emerald-200"}`}
            data-testid="button-toggle-timer"
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isRunning ? "Pausar" : "Retomar"}
          </button>
          <button
            onClick={handleTerminar}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-red-500 text-white font-display font-bold text-sm active:scale-[0.98] transition-all shadow-sm shadow-red-200"
            data-testid="button-end-match"
          >
            <StopCircle className="w-4 h-4" />
            Terminar
          </button>
        </div>

        {/* Two-column player selector */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-4 pt-3 pb-2 border-b border-gray-50">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Registar ação para</p>
            {selectedPlayer && (
              <div className="flex items-center gap-2 mt-2">
                <div className={`w-5 h-5 rounded-full ${posColors[selectedPlayer.position] || "bg-gray-400"} flex items-center justify-center`}>
                  <span className="text-white text-[8px] font-bold">{selectedPlayer.position[0]}</span>
                </div>
                <span className="font-bold text-gray-900 text-sm">{selectedPlayer.name}</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${selectedPlayer.team === "home" ? "bg-primary/10 text-primary" : "bg-blue-50 text-blue-600"}`}>
                  {selectedPlayer.team === "home" ? "Os Leões" : "FC Baixa"}
                </span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 divide-x divide-gray-100">
            {/* Home team */}
            <div>
              <div className="px-3 py-2 bg-primary/5 border-b border-gray-100">
                <p className="text-[10px] font-black text-primary uppercase tracking-widest">⚽ Os Leões</p>
              </div>
              <div className="divide-y divide-gray-50">
                {homePlayers.map((p) => {
                  const isSelected = selectedPlayer?.id === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setSelectedPlayer(p)}
                      className={`w-full flex items-center gap-2 px-3 py-2.5 text-left transition-colors ${isSelected ? "bg-primary/8" : "hover:bg-gray-50 active:bg-gray-100"}`}
                      data-testid={`player-home-${p.id}`}
                    >
                      <div className={`w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center ${isSelected ? "bg-primary" : posColors[p.position] || "bg-gray-400"}`}>
                        <span className="text-white text-[9px] font-bold">{p.position}</span>
                      </div>
                      <span className={`text-xs font-semibold truncate ${isSelected ? "text-primary" : "text-gray-700"}`}>
                        {p.name.split(" ")[0]}
                      </span>
                      {isSelected && <span className="ml-auto text-primary text-xs flex-shrink-0">●</span>}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Away team */}
            <div>
              <div className="px-3 py-2 bg-blue-50 border-b border-gray-100">
                <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest">🛡 FC Baixa</p>
              </div>
              <div className="divide-y divide-gray-50">
                {awayPlayers.map((p) => {
                  const isSelected = selectedPlayer?.id === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setSelectedPlayer(p)}
                      className={`w-full flex items-center gap-2 px-3 py-2.5 text-left transition-colors ${isSelected ? "bg-blue-50" : "hover:bg-gray-50 active:bg-gray-100"}`}
                      data-testid={`player-away-${p.id}`}
                    >
                      <div className={`w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center ${isSelected ? "bg-blue-500" : posColors[p.position] || "bg-gray-400"}`}>
                        <span className="text-white text-[9px] font-bold">{p.position}</span>
                      </div>
                      <span className={`text-xs font-semibold truncate ${isSelected ? "text-blue-600" : "text-gray-700"}`}>
                        {p.name.split(" ")[0]}
                      </span>
                      {isSelected && <span className="ml-auto text-blue-500 text-xs flex-shrink-0">●</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Event Buttons */}
        <div>
          <p className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2.5">Registar evento</p>
          <div className="grid grid-cols-5 gap-2">
            {eventTypes.map((et) => {
              const count = events.filter((e) => e.type === et.key).length;
              return (
                <button
                  key={et.key}
                  onClick={() => addEvent(et.key)}
                  className={`relative flex flex-col items-center justify-center gap-1 rounded-2xl py-3 px-1 bg-gradient-to-br ${et.bgColor} shadow-md active:scale-95 transition-all duration-150`}
                  data-testid={`event-btn-${et.key}`}
                >
                  <span className="text-2xl">{et.emoji}</span>
                  <span className="text-white font-bold text-[10px] leading-tight text-center">{et.label}</span>
                  {count > 0 && (
                    <div className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-white border-2 flex items-center justify-center" style={{ borderColor: et.borderColor }}>
                      <span className="font-black text-[10px]" style={{ color: et.borderColor }}>{count}</span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
