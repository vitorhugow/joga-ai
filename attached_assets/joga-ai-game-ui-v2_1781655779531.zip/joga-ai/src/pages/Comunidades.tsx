import { Search, Plus } from "lucide-react";
import { useState } from "react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNavigation } from "@/components/BottomNavigation";
import { CommunityCard } from "@/components/CommunityCard";
import { SectionHeader } from "@/components/SectionHeader";
import { mockData } from "@/data/mockData";

const allCommunities = [
  ...mockData.communities,
  { id: "4", name: "Futsal Cascais", city: "Cascais", memberCount: 67, gameType: "futsal", coverImage: "https://images.unsplash.com/photo-1574629810360-7efbbe195018" },
  { id: "5", name: "Braga United", city: "Braga", memberCount: 110, gameType: "fut7", coverImage: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e" },
];

export default function Comunidades() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("todas");

  const filters = ["todas", "futsal", "fut5", "fut7", "futebol11"];
  const filterLabels: Record<string, string> = {
    todas: "Todas", futsal: "Futsal", fut5: "Fut 5", fut7: "Fut 7", futebol11: "Fut 11"
  };

  const filtered = allCommunities.filter((c) => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.city.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "todas" || c.gameType === filter;
    return matchSearch && matchFilter;
  });

  const myCommunities = allCommunities.slice(0, 2);

  return (
    <div className="stadium-shell min-h-screen pb-28">
      <AppHeader
        title="Comunidades"
        rightElement={
          <button className="flex items-center gap-1.5 text-primary text-sm font-semibold" data-testid="button-create-community">
            <Plus className="w-4 h-4" />
            Criar
          </button>
        }
      />

      <div className="px-4 space-y-5 pt-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="search"
            placeholder="Pesquisar comunidades..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
            data-testid="input-search-communities"
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto pb-1 -mx-4 px-4 scrollbar-none">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-all ${filter === f ? "bg-primary text-white shadow-sm" : "bg-white text-gray-600 border border-gray-200"}`}
              data-testid={`filter-${f}`}
            >
              {filterLabels[f]}
            </button>
          ))}
        </div>

        {/* My Communities */}
        {search === "" && filter === "todas" && (
          <div>
            <SectionHeader title="As Minhas" className="mb-3" />
            <div className="space-y-3">
              {myCommunities.map((c) => (
                <CommunityCard key={c.id} {...c} joined />
              ))}
            </div>
          </div>
        )}

        {/* Discover */}
        <div>
          <SectionHeader title={search || filter !== "todas" ? "Resultados" : "Descobrir"} className="mb-3" />
          {filtered.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-400 text-sm">Nenhuma comunidade encontrada</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map((c) => (
                <CommunityCard key={c.id} {...c} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
