import { useState } from "react";
import { useLocation } from "wouter";
import { Calendar, MapPin, Users, Zap, ChevronDown } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNavigation } from "@/components/BottomNavigation";

export default function CriarPartida() {
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({
    title: "",
    city: "",
    location: "",
    gameType: "fut7",
    level: "recreativo",
    date: "",
    time: "",
    maxPlayers: "14",
    price: "",
    openToExternal: true,
    notes: "",
  });

  function set(key: string, value: string | boolean) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLocation("/partida/100/pre-jogo");
  }

  const gameTypes = [
    { value: "futsal", label: "Futsal" },
    { value: "fut5", label: "Fut 5" },
    { value: "fut7", label: "Fut 7" },
    { value: "futebol11", label: "Futebol 11" },
  ];

  const levels = [
    { value: "recreativo", label: "Recreativo" },
    { value: "misto", label: "Misto" },
    { value: "competitivo", label: "Competitivo" },
  ];

  return (
    <div className="stadium-shell min-h-screen pb-28">
      <AppHeader title="Criar Partida" showBack backUrl="/jogos" />

      <form onSubmit={handleSubmit} className="px-4 pt-4 space-y-5">
        {/* Title */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
            Nome da Partida
          </label>
          <input
            type="text"
            placeholder="Ex: Peladinha de Sexta"
            value={form.title}
            onChange={(e) => set("title", e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
            data-testid="input-match-title"
            required
          />
        </div>

        {/* Game Type */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
            Tipo de Futebol
          </label>
          <div className="grid grid-cols-4 gap-2">
            {gameTypes.map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => set("gameType", t.value)}
                className={`py-2.5 rounded-xl text-sm font-display font-semibold transition-all ${form.gameType === t.value ? "bg-primary text-white shadow-sm" : "bg-white text-gray-600 border border-gray-200"}`}
                data-testid={`game-type-${t.value}`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Level */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
            Nível do Jogo
          </label>
          <div className="grid grid-cols-3 gap-2">
            {levels.map((l) => (
              <button
                key={l.value}
                type="button"
                onClick={() => set("level", l.value)}
                className={`py-2.5 rounded-xl text-sm font-display font-semibold transition-all ${form.level === l.value ? "bg-primary text-white shadow-sm" : "bg-white text-gray-600 border border-gray-200"}`}
                data-testid={`level-${l.value}`}
              >
                {l.label}
              </button>
            ))}
          </div>
        </div>

        {/* City + Location */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Cidade</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type="text"
                placeholder="Lisboa"
                value={form.city}
                onChange={(e) => set("city", e.target.value)}
                className="w-full pl-8 pr-3 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                data-testid="input-city"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Local</label>
            <input
              type="text"
              placeholder="Nome do campo"
              value={form.location}
              onChange={(e) => set("location", e.target.value)}
              className="w-full px-3 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              data-testid="input-location"
            />
          </div>
        </div>

        {/* Date + Time */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Data</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
              <input
                type="date"
                value={form.date}
                onChange={(e) => set("date", e.target.value)}
                className="w-full pl-8 pr-3 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                data-testid="input-date"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Hora</label>
            <input
              type="time"
              value={form.time}
              onChange={(e) => set("time", e.target.value)}
              className="w-full px-3 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              data-testid="input-time"
            />
          </div>
        </div>

        {/* Max Players + Price */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
              <Users className="inline w-3 h-3 mr-1" />
              Nº Jogadores
            </label>
            <input
              type="number"
              min="4"
              max="22"
              value={form.maxPlayers}
              onChange={(e) => set("maxPlayers", e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              data-testid="input-max-players"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
              <Zap className="inline w-3 h-3 mr-1" />
              Preço/Jogador
            </label>
            <input
              type="text"
              placeholder="Grátis ou ex: 5€"
              value={form.price}
              onChange={(e) => set("price", e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              data-testid="input-price"
            />
          </div>
        </div>

        {/* Open to external */}
        <div className="flex items-center justify-between bg-white rounded-xl border border-gray-200 px-4 py-3">
          <div>
            <p className="text-sm font-semibold text-gray-900">Aberto a jogadores externos</p>
            <p className="text-xs text-gray-400 mt-0.5">Jogadores fora da comunidade podem participar</p>
          </div>
          <button
            type="button"
            onClick={() => set("openToExternal", !form.openToExternal)}
            className={`relative w-11 h-6 rounded-full transition-colors ${form.openToExternal ? "bg-primary" : "bg-gray-200"}`}
            data-testid="toggle-open-external"
          >
            <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${form.openToExternal ? "left-5" : "left-0.5"}`} />
          </button>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Observações</label>
          <textarea
            placeholder="Informações adicionais sobre a partida..."
            value={form.notes}
            onChange={(e) => set("notes", e.target.value)}
            rows={3}
            className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
            data-testid="input-notes"
          />
        </div>

        {/* Submit */}
        <button
          type="submit"
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-primary to-emerald-600 text-white font-display font-bold text-lg shadow-md shadow-emerald-100 active:scale-[0.98] transition-all"
          data-testid="button-submit-match"
        >
          Criar Partida
        </button>
      </form>
    </div>
  );
}
