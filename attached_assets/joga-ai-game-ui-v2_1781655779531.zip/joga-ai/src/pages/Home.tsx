import { Link } from "wouter";
import { Plus, Search, ChevronRight, Trophy, Flame, Bell, ChevronDown } from "lucide-react";
import { mockData } from "@/data/mockData";
import { calculateOverall, PlayerAttributes } from "@/lib/cardUtils";
import { PlayerCard } from "@/components/PlayerCard";

/* ─── Pitch texture SVG as data-url ─── */
const PITCH_SVG = `url("data:image/svg+xml,%3Csvg width='80' height='80' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 40 L80 40' stroke='rgba(255,255,255,0.05)' stroke-width='1'/%3E%3Cpath d='M40 0 L40 80' stroke='rgba(255,255,255,0.03)' stroke-width='1'/%3E%3Ccircle cx='40' cy='40' r='18' stroke='rgba(255,255,255,0.04)' stroke-width='1' fill='none'/%3E%3C/svg%3E")`;

/* ─── Tiny scaled PlayerCard for hero ─── */
function HeroCard({ player, overall }: { player: typeof mockData.currentPlayer; overall: number }) {
  return (
    <Link href="/perfil" data-testid="hero-player-card">
      <div className="active:scale-95 transition-transform cursor-pointer" style={{ width: 92, height: 127, overflow: "hidden", flexShrink: 0, filter: "drop-shadow(0 8px 24px rgba(0,0,0,0.5))" }}>
        <div style={{ width: 300, transform: "scale(0.306)", transformOrigin: "top left", pointerEvents: "none" }}>
          <PlayerCard
            name={player.name}
            position={player.position}
            attributes={player.attributes}
            shirtNumber={player.shirtNumber}
            title={player.title}
          />
        </div>
      </div>
    </Link>
  );
}

/* ─── Community pill in scroll ─── */
function CommunityPill({ c }: { c: { id: string; name: string; memberCount: number; city: string } }) {
  const abbr = c.name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();
  const colors = [
    "linear-gradient(135deg, #16a34a, #047857)",
    "linear-gradient(135deg, #2563eb, #1d4ed8)",
    "linear-gradient(135deg, #7c3aed, #6d28d9)",
    "linear-gradient(135deg, #dc2626, #b91c1c)",
    "linear-gradient(135deg, #d97706, #b45309)",
  ];
  const bg = colors[parseInt(c.id) % colors.length];

  return (
    <Link href={`/comunidades/${c.id}`}>
      <div className="flex-shrink-0 flex flex-col items-center gap-2 active:scale-95 transition-transform" data-testid={`community-pill-${c.id}`}>
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg"
          style={{ background: bg, boxShadow: "0 4px 12px rgba(0,0,0,0.2)" }}
        >
          <span className="font-display font-black text-white text-xl">{abbr}</span>
        </div>
        <p className="text-gray-700 text-[11px] font-bold max-w-[60px] text-center leading-tight">{c.name.split(" ")[0]}</p>
        <p className="text-gray-400 text-[10px] font-medium -mt-1">{c.memberCount}</p>
      </div>
    </Link>
  );
}

export default function Home() {
  const player = mockData.currentPlayer;
  const overall = calculateOverall(player.attributes);
  const liveMatch = mockData.liveMatches[0];
  const available = mockData.availableMatches.filter((m) => m.spotsRemaining !== "Lotado");

  const ranking = [
    { rank: 1, name: "Bruno Fernandes", position: "MEI", overall: 74, isMe: false },
    { rank: 2, name: "Pedro Santos",    position: "MEI", overall: 70, isMe: false },
    { rank: 3, name: "Miguel Costa",    position: "GR",  overall: 68, isMe: false },
    { rank: 4, name: player.name,       position: player.position, overall, isMe: true },
  ];

  return (
    <div className="stadium-shell min-h-screen pb-28">

      {/* ══════════════════════════════════════════
          HERO
      ══════════════════════════════════════════ */}
      <div
        className="relative overflow-hidden stadium-lights"
        style={{
          background: "linear-gradient(155deg, #020617 0%, #04230e 24%, #0a5a1e 62%, #10b981 100%)",
          paddingBottom: 32,
        }}
      >
        {/* Pitch texture */}
        <div className="absolute inset-0" style={{ backgroundImage: PITCH_SVG, backgroundSize: "80px 80px" }} />
        {/* Radial glow */}
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 70% 60%, rgba(22,163,74,0.22) 0%, transparent 65%)" }} />
        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-14" style={{ background: "linear-gradient(to top, #f0f2f5, transparent)" }} />

        {/* Header row */}
        <div className="relative flex items-center justify-between px-5 pt-5 pb-4">
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md"
              style={{ background: "linear-gradient(135deg, #16a34a, #15803d)" }}
            >
              <span className="text-white font-display font-black text-base">JA</span>
            </div>
            <span className="font-display font-black text-white text-xl tracking-tight">
              Joga <span style={{ color: "#4ade80" }}>AI</span>
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.1)" }}>
              <Bell className="w-4 h-4 text-white" />
            </button>
            <Link href="/premium">
              <div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
                style={{ background: "rgba(251,191,36,0.15)", border: "1px solid rgba(251,191,36,0.5)" }}
                data-testid="button-premium-header"
              >
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-amber-400 text-xs font-bold">Premium</span>
              </div>
            </Link>
          </div>
        </div>

        {/* Player row */}
        <div className="relative flex items-center gap-5 px-5">
          <HeroCard player={player} overall={overall} />

          <div className="flex-1 min-w-0">
            <p className="text-white/40 text-[10px] font-bold uppercase tracking-[0.2em] mb-1">Em Destaque</p>
            <h1 className="font-display font-black text-white uppercase leading-none tracking-tight" style={{ fontSize: "1.9rem" }}>
              {player.name.split(" ")[0]}
            </h1>
            <h1 className="font-display font-black text-white uppercase leading-none tracking-tight -mt-0.5" style={{ fontSize: "1.9rem" }}>
              {player.name.split(" ").slice(1).join(" ")}
            </h1>
            <div className="flex items-center gap-2 mt-2">
              <span
                className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider"
                style={{ background: "rgba(74,222,128,0.2)", color: "#4ade80", border: "1px solid rgba(74,222,128,0.3)" }}
              >
                {player.position}
              </span>
              <span className="text-white/40 text-[10px]">·</span>
              <span className="text-white/60 text-[11px] font-medium">{player.title}</span>
            </div>

            {/* Stats inline */}
            <div className="flex items-center gap-4 mt-4">
              {[
                { v: player.seasonStats.goals, l: "Golos" },
                { v: player.seasonStats.assists, l: "Assist." },
                { v: player.seasonStats.matches, l: "Jogos" },
              ].map((s, i) => (
                <div key={s.l} className="flex items-center gap-3">
                  {i > 0 && <div className="w-px h-6" style={{ background: "rgba(255,255,255,0.15)" }} />}
                  <div>
                    <p className="font-display font-black text-white text-xl leading-none">{s.v}</p>
                    <p className="text-white/35 text-[10px] font-medium mt-0.5">{s.l}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 space-y-4 pt-2">

        {/* ══════════════════════════════════════════
            LIVE BANNER
        ══════════════════════════════════════════ */}
        {liveMatch && (
          <Link href="/partida/100/ao-vivo">
            <div
              className="rounded-2xl overflow-hidden active:scale-[0.98] transition-all"
              style={{ background: "linear-gradient(125deg, #b91c1c 0%, #dc2626 45%, #ef4444 100%)", boxShadow: "0 6px 24px rgba(220,38,38,0.4)" }}
              data-testid="live-match-banner"
            >
              <div className="flex items-center justify-between px-4 py-3.5">
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
                    <span className="text-white/70 text-[10px] font-bold uppercase tracking-widest">Ao Vivo</span>
                  </div>
                  <div className="w-px h-4" style={{ background: "rgba(255,255,255,0.25)" }} />
                  <span className="text-white font-display font-bold text-sm">{liveMatch.title}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-display font-black text-white text-3xl leading-none tracking-tight">
                    {liveMatch.score.home}–{liveMatch.score.away}
                  </span>
                  <div
                    className="text-[10px] font-bold px-2 py-1 rounded-lg"
                    style={{ background: "rgba(0,0,0,0.25)", color: "rgba(255,255,255,0.75)" }}
                  >
                    {liveMatch.time}
                  </div>
                </div>
              </div>
            </div>
          </Link>
        )}

        {/* ══════════════════════════════════════════
            QUICK ACTIONS
        ══════════════════════════════════════════ */}
        <div className="grid grid-cols-2 gap-3">
          <Link href="/criar-partida" data-testid="button-create-match">
            <div
              className="game-button rounded-2xl p-4 flex items-center gap-3.5 active:scale-[0.97] transition-all"
              style={{ background: "linear-gradient(135deg, #15803d, #16a34a)", boxShadow: "0 4px 16px rgba(21,128,61,0.35)" }}
            >
              <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(255,255,255,0.15)" }}>
                <Plus className="w-6 h-6 text-white" strokeWidth={2.5} />
              </div>
              <div>
                <p className="font-display font-black text-white text-base leading-tight">Criar</p>
                <p className="text-white/60 text-xs font-medium">Partida nova</p>
              </div>
            </div>
          </Link>
          <Link href="/jogos" data-testid="button-find-match">
            <div
              className="game-button rounded-2xl p-4 flex items-center gap-3.5 active:scale-[0.97] transition-all"
              style={{ background: "linear-gradient(135deg, #1d4ed8, #2563eb)", boxShadow: "0 4px 16px rgba(29,78,216,0.35)" }}
            >
              <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: "rgba(255,255,255,0.15)" }}>
                <Search className="w-6 h-6 text-white" strokeWidth={2} />
              </div>
              <div>
                <p className="font-display font-black text-white text-base leading-tight">Encontrar</p>
                <p className="text-white/60 text-xs font-medium">Jogos perto</p>
              </div>
            </div>
          </Link>
        </div>

        {/* ══════════════════════════════════════════
            PRÓXIMO JOGO
        ══════════════════════════════════════════ */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display font-black text-gray-900 text-lg">Próximo Jogo</h2>
            <Link href="/jogos"><span className="text-primary text-sm font-semibold flex items-center gap-0.5">Ver todos <ChevronRight className="w-3.5 h-3.5" /></span></Link>
          </div>
          <div className="game-panel rounded-2xl overflow-hidden">
            {/* Top colour band */}
            <div className="h-1.5" style={{ background: "linear-gradient(90deg, #16a34a, #059669, #2563eb)" }} />
            <div className="px-4 pt-3.5 pb-2">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-display font-black text-gray-900 text-lg leading-tight">Peladinha de Sexta</p>
                  <p className="text-gray-400 text-sm mt-0.5">📍 Parque das Nações</p>
                </div>
                <div className="text-right flex-shrink-0 ml-3">
                  <div className="inline-flex flex-col items-end">
                    <span className="font-display font-black text-primary text-sm">Sexta</span>
                    <span className="font-display font-bold text-gray-900 text-xl leading-none">20:00</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-3">
                <span className="text-[11px] text-gray-500 px-2.5 py-1 rounded-lg font-semibold" style={{ background: "#f3f4f6" }}>⚽ Fut 7</span>
                <span className="text-[11px] text-emerald-700 px-2.5 py-1 rounded-lg font-semibold" style={{ background: "#f0fdf4" }}>Recreativo</span>
                <span className="text-[11px] text-blue-700 px-2.5 py-1 rounded-lg font-semibold ml-auto" style={{ background: "#eff6ff" }}>3 vagas</span>
              </div>
            </div>
            <div className="px-4 py-3 flex items-center gap-2 border-t border-gray-50">
              <div className="flex -space-x-2 flex-shrink-0">
                {["B","P","M","J","R"].map((l, i) => (
                  <div
                    key={i}
                    className="w-7 h-7 rounded-full border-2 border-white flex items-center justify-center"
                    style={{ background: `hsl(${140 + i * 20}, 65%, 38%)`, fontSize: 10, fontWeight: 800, color: "white" }}
                  >
                    {l}
                  </div>
                ))}
                <div className="w-7 h-7 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center">
                  <span className="text-gray-500 text-[9px] font-bold">+3</span>
                </div>
              </div>
              <p className="text-gray-400 text-xs font-medium">8 inscritos · 3 vagas restantes</p>
            </div>
          </div>
        </div>

        {/* ══════════════════════════════════════════
            COMUNIDADES
        ══════════════════════════════════════════ */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display font-black text-gray-900 text-lg">Comunidades</h2>
            <Link href="/comunidades"><span className="text-primary text-sm font-semibold flex items-center gap-0.5">Ver todas <ChevronRight className="w-3.5 h-3.5" /></span></Link>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-1 -mx-4 px-4">
            {mockData.communities.map((c) => (
              <CommunityPill key={c.id} c={c} />
            ))}
            <Link href="/comunidades">
              <div className="flex-shrink-0 flex flex-col items-center gap-2 active:scale-95 transition-transform">
                <div className="w-16 h-16 rounded-2xl bg-gray-100 flex items-center justify-center border-2 border-dashed border-gray-200">
                  <Plus className="w-5 h-5 text-gray-400" />
                </div>
                <p className="text-gray-400 text-[11px] font-medium">Explorar</p>
              </div>
            </Link>
          </div>
        </div>

        {/* ══════════════════════════════════════════
            JOGOS DISPONÍVEIS
        ══════════════════════════════════════════ */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display font-black text-gray-900 text-lg">Jogos Disponíveis</h2>
            <Link href="/jogos"><span className="text-primary text-sm font-semibold flex items-center gap-0.5">Ver todos <ChevronRight className="w-3.5 h-3.5" /></span></Link>
          </div>
          <div className="space-y-2.5">
            {available.map((m) => (
              <div
                key={m.id}
                className="game-panel rounded-2xl px-4 py-3.5 flex items-center gap-3.5"
                data-testid={`home-match-${m.id}`}
              >
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 text-xl"
                  style={{ background: "linear-gradient(135deg, #f0fdf4, #dcfce7)" }}
                >
                  ⚽
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-display font-bold text-gray-900 text-sm leading-tight truncate">{m.title}</p>
                  <p className="text-gray-400 text-[11px] mt-0.5 truncate">📍 {m.location}</p>
                  <p className="text-gray-500 text-[11px] mt-0.5 font-medium">{m.date}</p>
                </div>
                <div className="flex flex-col items-end gap-1 flex-shrink-0">
                  <span
                    className="text-[11px] font-bold px-2.5 py-1 rounded-lg"
                    style={{ background: "#f0fdf4", color: "#16a34a" }}
                  >
                    {m.spotsRemaining}
                  </span>
                  <span className="text-[10px] text-gray-300 font-medium">{m.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ══════════════════════════════════════════
            RANKING SEMANAL
        ══════════════════════════════════════════ */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display font-black text-gray-900 text-lg">Ranking Semanal</h2>
            <Link href="/ranking"><span className="text-primary text-sm font-semibold flex items-center gap-0.5">Ver tudo <ChevronRight className="w-3.5 h-3.5" /></span></Link>
          </div>
          <div className="game-panel rounded-2xl overflow-hidden">
            <div
              className="px-4 py-3 flex items-center gap-2"
              style={{ background: "linear-gradient(135deg, #fbbf24, #f59e0b)" }}
            >
              <Trophy className="w-4 h-4 text-amber-900" />
              <span className="font-display font-bold text-amber-900 text-sm uppercase tracking-wider">Top Jogadores</span>
              <span className="ml-auto text-amber-900/60 text-xs font-medium">Esta semana</span>
            </div>
            <div className="divide-y divide-gray-50">
              {ranking.map((r) => (
                <div
                  key={r.rank}
                  className="px-4 py-3 flex items-center gap-3"
                  style={{ background: r.isMe ? "rgba(22,163,74,0.04)" : "white" }}
                  data-testid={`home-rank-${r.rank}`}
                >
                  <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-base font-display font-black">
                    {r.rank === 1 ? "🥇" : r.rank === 2 ? "🥈" : r.rank === 3 ? "🥉" : <span className="text-gray-400 text-sm">{r.rank}º</span>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-semibold text-sm truncate ${r.isMe ? "text-primary" : "text-gray-800"}`}>
                      {r.name}{r.isMe ? " (Tu)" : ""}
                    </p>
                    <p className="text-gray-400 text-xs">{r.position}</p>
                  </div>
                  <span className={`font-display font-black text-xl ${r.rank === 1 ? "text-amber-500" : r.isMe ? "text-primary" : "text-gray-700"}`}>
                    {r.overall}
                  </span>
                </div>
              ))}
            </div>
            <Link href="/ranking">
              <div className="px-4 py-3 border-t border-gray-50 flex items-center justify-center gap-1 active:bg-gray-50 transition-colors">
                <span className="text-primary text-sm font-semibold">Ver ranking completo</span>
                <ChevronRight className="w-4 h-4 text-primary" />
              </div>
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
}
