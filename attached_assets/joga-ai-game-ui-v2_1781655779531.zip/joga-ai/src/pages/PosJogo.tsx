import { useState } from "react";
import { useLocation } from "wouter";
import { TrendingUp, Trophy, Home } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { MatchSummaryCard } from "@/components/MatchSummaryCard";
import { SectionHeader } from "@/components/SectionHeader";
import { PlayerBadge } from "@/components/PlayerBadge";
import { mockData } from "@/data/mockData";
import { calculateOverall } from "@/lib/cardUtils";

const matchPlayers = [
  { id: "1", name: "Diogo Ferreira",  position: "AVA", overall: calculateOverall(mockData.currentPlayer.attributes), goals: 2, assists: 1, saves: 0, fouls: 1, rating: 8.0 },
  { id: "2", name: "João Silva",       position: "DEF", overall: 65,  goals: 0, assists: 1, saves: 0, fouls: 2, rating: 7.1 },
  { id: "3", name: "Pedro Santos",     position: "MEI", overall: 70,  goals: 1, assists: 2, saves: 0, fouls: 0, rating: 8.7 },
  { id: "4", name: "Miguel Costa",     position: "GR",  overall: 68,  goals: 0, assists: 0, saves: 4, fouls: 0, rating: 7.6 },
  { id: "5", name: "Bruno Fernandes",  position: "MEI", overall: 74,  goals: 0, assists: 1, saves: 0, fouls: 1, rating: 7.8 },
];

/* Only: atributo + delta + reason. No detail/explanation. */
const evolutionItems = [
  { attr: "Ritmo",       delta: +1, reason: "Presença confirmada",   color: "text-emerald-600", bg: "bg-emerald-50",  border: "border-emerald-200" },
  { attr: "Finalização", delta: +2, reason: "2 golos marcados",      color: "text-emerald-600", bg: "bg-emerald-50",  border: "border-emerald-200" },
  { attr: "Passe",       delta: +1, reason: "1 assistência",         color: "text-blue-600",    bg: "bg-blue-50",     border: "border-blue-200"    },
  { attr: "Físico",      delta: +1, reason: "Votação concluída",     color: "text-purple-600",  bg: "bg-purple-50",   border: "border-purple-200"  },
  { attr: "Defesa",      delta: -1, reason: "1 falta cometida",      color: "text-red-600",     bg: "bg-red-50",      border: "border-red-200"     },
];

const mvpPlayer = matchPlayers.reduce((best, p) => (p.rating > best.rating ? p : best), matchPlayers[0]);

/* ── Half-star voting ─────────────────────────────────────── */
function VoteStars({ playerId }: { playerId: string }) {
  const [rating, setRating] = useState(0);
  const [hovered, setHovered] = useState(0);
  const display = hovered || rating;

  function handleClick(e: React.MouseEvent<HTMLButtonElement>, star: number) {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    setRating(x < rect.width / 2 ? star - 0.5 : star);
  }

  function handleMove(e: React.MouseEvent<HTMLButtonElement>, star: number) {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    setHovered(x < rect.width / 2 ? star - 0.5 : star);
  }

  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-0.5" onMouseLeave={() => setHovered(0)}>
        {[1, 2, 3, 4, 5].map((star) => {
          const full = display >= star;
          const half = !full && display >= star - 0.5;
          return (
            <button
              key={star}
              className="p-0.5 transition-transform active:scale-110"
              onClick={(e) => handleClick(e, star)}
              onMouseMove={(e) => handleMove(e, star)}
              data-testid={`star-${playerId}-${star}`}
            >
              <svg width="26" height="26" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="#e5e7eb" />
                {(full || half) && (
                  <>
                    <clipPath id={`cp-${playerId}-${star}`}>
                      <rect x="0" y="0" width={half ? "12" : "24"} height="24" />
                    </clipPath>
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="#fbbf24" clipPath={`url(#cp-${playerId}-${star})`} />
                  </>
                )}
              </svg>
            </button>
          );
        })}
      </div>
      <span className="font-display font-bold text-gray-600 text-sm w-8">
        {rating > 0 ? (rating * 2).toFixed(1) : "—"}
      </span>
      {rating > 0 && <span className="text-xs text-emerald-600 font-semibold">✓</span>}
    </div>
  );
}

export default function PosJogo() {
  const [, setLocation] = useLocation();
  const [tab, setTab] = useState<"resultado" | "votacao" | "evolucao">("resultado");

  return (
    <div className="stadium-shell min-h-screen pb-28">
      <AppHeader title="Pós-Jogo" showBack backUrl="/" />

      <div className="px-4 pt-4 space-y-4">
        <MatchSummaryCard homeTeam="Os Leões" awayTeam="FC Baixa" homeScore={3} awayScore={1} date="Sex, 20:00" gameType="Fut 7" />

        {/* Tabs */}
        <div className="flex gap-1 bg-white rounded-2xl border border-gray-100 shadow-sm p-1">
          {(["resultado", "votacao", "evolucao"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${tab === t ? "bg-primary text-white shadow-sm" : "text-gray-500 hover:text-gray-700"}`}
              data-testid={`tab-${t}`}
            >
              {t === "resultado" ? "Resumo" : t === "votacao" ? "Votação" : "Evolução"}
            </button>
          ))}
        </div>

        {/* ── RESUMO ── */}
        {tab === "resultado" && (
          <div className="space-y-4">
            {/* MVP automático */}
            <div className="bg-gradient-to-br from-amber-400 to-yellow-500 rounded-2xl px-4 py-4 flex items-center gap-4 shadow-md shadow-amber-100">
              <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                <Trophy className="w-7 h-7 text-white" />
              </div>
              <div>
                <p className="text-amber-900/70 text-[10px] font-bold uppercase tracking-widest">Melhor em Campo</p>
                <p className="font-display font-black text-amber-950 text-xl leading-tight">{mvpPlayer.name}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-amber-800 text-sm">★</span>
                  <span className="text-amber-900 text-sm font-bold">{mvpPlayer.rating} média</span>
                  <span className="text-amber-800/60 text-xs">· {mvpPlayer.position}</span>
                </div>
              </div>
            </div>

            {/* As tuas estatísticas */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-4 py-4">
              <SectionHeader title="As Tuas Estatísticas" className="mb-4" />
              <div className="grid grid-cols-3 gap-4 text-center">
                {[
                  { label: "Golos",   value: 2,     color: "text-emerald-600" },
                  { label: "Assist.", value: 1,     color: "text-blue-600" },
                  { label: "Defesas", value: 0,     color: "text-purple-600" },
                  { label: "Faltas",  value: 1,     color: "text-orange-500" },
                  { label: "Cartões", value: 0,     color: "text-red-500" },
                  { label: "Nota",    value: "8.0", color: "text-amber-500" },
                ].map((s) => (
                  <div key={s.label} data-testid={`postgame-stat-${s.label.toLowerCase()}`}>
                    <p className={`font-display font-black text-2xl ${s.color}`}>{s.value}</p>
                    <p className="text-gray-400 text-[10px] uppercase tracking-wide">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Notas de todos */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-50">
                <SectionHeader title="Notas da Partida" />
              </div>
              <div className="divide-y divide-gray-50">
                {[...matchPlayers].sort((a, b) => b.rating - a.rating).map((p, idx) => (
                  <div key={p.id} className={`flex items-center gap-3 px-4 py-3 ${p.id === "1" ? "bg-primary/5" : ""}`} data-testid={`player-rating-${p.id}`}>
                    <PlayerBadge overall={p.overall} position={p.position} size="sm" />
                    <div className="flex-1 min-w-0">
                      <p className={`font-semibold text-sm truncate ${p.id === "1" ? "text-primary" : "text-gray-900"}`}>{p.name}</p>
                      <p className="text-xs text-gray-400">{p.goals}G · {p.assists}A{p.saves > 0 ? ` · ${p.saves} def.` : ""}</p>
                    </div>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-display font-black text-lg ${idx === 0 ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-700"}`}>
                      {p.rating}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── VOTAÇÃO ── */}
        {tab === "votacao" && (
          <div className="space-y-3">
            <div className="bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3 flex items-start gap-3">
              <span className="text-amber-500 text-sm mt-0.5 flex-shrink-0">★</span>
              <p className="text-amber-800 text-xs leading-relaxed">
                A votação fica pendente durante 24 horas. O MVP é calculado automaticamente pelas notas.
              </p>
            </div>

            {matchPlayers.map((p) => (
              <div key={p.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden" data-testid={`vote-card-${p.id}`}>
                <div className={`px-4 py-3 flex items-center gap-3 ${p.id === mvpPlayer.id ? "bg-amber-50" : ""}`}>
                  <PlayerBadge overall={p.overall} position={p.position} size="sm" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="font-semibold text-gray-900 text-sm truncate">{p.name}</p>
                      {p.id === mvpPlayer.id && <Trophy className="w-3.5 h-3.5 text-amber-500 flex-shrink-0" />}
                    </div>
                    <p className="text-xs text-gray-400">{p.goals}G · {p.assists}A</p>
                  </div>
                  <div className="font-display font-black text-amber-500 text-xl">{p.rating}</div>
                </div>
                <div className="px-4 py-3 border-t border-gray-50">
                  <p className="text-[10px] text-gray-400 mb-2 uppercase tracking-wider">A tua avaliação (meia estrela disponível)</p>
                  <VoteStars playerId={p.id} />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── EVOLUÇÃO ── */}
        {tab === "evolucao" && (
          <div className="space-y-4">
            <div className="space-y-2.5">
              {evolutionItems.map((evo, i) => (
                <div
                  key={i}
                  className={`${evo.bg} border ${evo.border} rounded-2xl px-4 py-3.5 flex items-center gap-3`}
                  data-testid={`evolution-${evo.attr.toLowerCase()}`}
                >
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 bg-white/60`}>
                    <TrendingUp className={`w-5 h-5 ${evo.color} ${evo.delta < 0 ? "rotate-180" : ""}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="font-display font-black text-gray-900 text-sm">{evo.attr}</span>
                    <span className={`font-display font-black text-lg leading-none ml-2 ${evo.color}`}>
                      {evo.delta > 0 ? `+${evo.delta}` : evo.delta}
                    </span>
                    <p className="text-gray-600 text-xs mt-0.5 leading-snug">{evo.reason}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Overall upgrade */}
            <div className="bg-gradient-to-br from-slate-800 to-slate-950 rounded-2xl px-5 py-5 text-center relative overflow-hidden">
              <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "repeating-linear-gradient(45deg, rgba(255,255,255,0.5) 0, rgba(255,255,255,0.5) 1px, transparent 0, transparent 50%)", backgroundSize: "12px 12px" }} />
              <div className="relative">
                <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-2">Overall actualizado</p>
                <div className="flex items-center justify-center gap-4 mb-3">
                  <span className="font-display font-black text-white/40 text-4xl">{calculateOverall(mockData.currentPlayer.attributes)}</span>
                  <div className="flex flex-col items-center">
                    <TrendingUp className="w-6 h-6 text-emerald-400" />
                    <span className="text-emerald-400 text-xs font-bold">+3</span>
                  </div>
                  <span className="font-display font-black text-emerald-400 text-5xl" style={{ textShadow: "0 0 20px rgba(52,211,110,0.4)" }}>
                    {calculateOverall(mockData.currentPlayer.attributes) + 3}
                  </span>
                </div>
                <p className="text-white/50 text-xs">A tua carta evoluiu com este jogo!</p>
              </div>
            </div>

            <button
              onClick={() => setLocation("/")}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-primary to-emerald-600 text-white font-display font-bold text-lg shadow-md shadow-emerald-100 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              data-testid="button-go-home"
            >
              <Home className="w-5 h-5" />
              Ver a Nova Carta
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
