import { useLocation } from "wouter";
import { Users, CheckCircle, Clock, CreditCard, Play } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNavigation } from "@/components/BottomNavigation";
import { PlayerMiniCard } from "@/components/PlayerMiniCard";
import { MiniPitch } from "@/components/MiniPitch";
import { SectionHeader } from "@/components/SectionHeader";
import { mockData } from "@/data/mockData";
import { calculateOverall } from "@/lib/cardUtils";

const confirmed = [
  { id: "1", name: "Diogo Ferreira", position: "AVA", overall: calculateOverall(mockData.currentPlayer.attributes), paid: true },
  { id: "2", name: "João Silva", position: "DEF", overall: 65, paid: true },
  { id: "3", name: "Pedro Santos", position: "MEI", overall: 70, paid: false },
  { id: "4", name: "Miguel Costa", position: "GR", overall: 68, paid: true },
  { id: "5", name: "Rui Patricio", position: "AVA", overall: 62, paid: false },
  { id: "6", name: "Bruno Fernandes", position: "MEI", overall: 74, paid: true },
];

const waiting = [
  { id: "7", name: "Carlos Sousa", position: "DEF", overall: 60 },
  { id: "8", name: "André Lima", position: "MEI", overall: 63 },
];

const teamColors = [
  { name: "Verde", value: "#16a34a" },
  { name: "Azul", value: "#2563eb" },
  { name: "Vermelho", value: "#dc2626" },
  { name: "Amarelo", value: "#ca8a04" },
];

export default function PreJogo() {
  const [, setLocation] = useLocation();

  return (
    <div className="stadium-shell min-h-screen pb-28">
      <AppHeader title="Pré-Jogo" showBack backUrl="/jogos" />

      <div className="px-4 pt-4 space-y-5">
        {/* Match Info */}
        <div className="bg-gradient-to-r from-primary to-emerald-600 rounded-2xl px-4 py-4 text-white">
          <p className="font-display font-bold text-xl">Os Leões vs FC Baixa</p>
          <div className="flex items-center gap-3 mt-1 text-white/70 text-sm">
            <span>Parque das Nações</span>
            <span>·</span>
            <span>Sexta, 20:00</span>
            <span>·</span>
            <span>Fut 7</span>
          </div>
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
            </div>
            <p className="font-display font-black text-xl text-gray-900">{confirmed.length}</p>
            <p className="text-[10px] text-gray-400 uppercase tracking-wide">Confirmados</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
            </div>
            <p className="font-display font-black text-xl text-gray-900">{waiting.length}</p>
            <p className="text-[10px] text-gray-400 uppercase tracking-wide">Em Espera</p>
          </div>
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-3 text-center">
            <div className="flex items-center justify-center gap-1 mb-1">
              <CreditCard className="w-3.5 h-3.5 text-blue-500" />
            </div>
            <p className="font-display font-black text-xl text-gray-900">{confirmed.filter((p) => p.paid).length}/{confirmed.length}</p>
            <p className="text-[10px] text-gray-400 uppercase tracking-wide">Pagos</p>
          </div>
        </div>

        {/* Mini Pitch */}
        <div>
          <SectionHeader title="Mini Campo" className="mb-3" />
          <div className="max-w-[240px] mx-auto">
            <MiniPitch homeTeam="Os Leões" awayTeam="FC Baixa" />
          </div>
        </div>

        {/* Confirmed Players */}
        <div>
          <SectionHeader title={`Confirmados (${confirmed.length})`} className="mb-3" />
          <div className="space-y-2">
            {confirmed.map((p) => (
              <div key={p.id} className="bg-white rounded-xl border border-gray-100 shadow-sm px-4 py-3 flex items-center justify-between" data-testid={`confirmed-player-${p.id}`}>
                <PlayerMiniCard name={p.name} position={p.position} overall={p.overall} />
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full flex-shrink-0 ${p.paid ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-amber-50 text-amber-700 border border-amber-200"}`}>
                  {p.paid ? "Pago" : "Pendente"}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Waiting List */}
        {waiting.length > 0 && (
          <div>
            <SectionHeader title={`Lista de Espera (${waiting.length})`} className="mb-3" />
            <div className="space-y-2 opacity-60">
              {waiting.map((p) => (
                <div key={p.id} className="bg-white rounded-xl border border-gray-200 shadow-sm px-4 py-3 flex items-center justify-between" data-testid={`waiting-player-${p.id}`}>
                  <PlayerMiniCard name={p.name} position={p.position} overall={p.overall} />
                  <span className="text-xs text-gray-400 font-medium">Em espera</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Start Button */}
        <button
          onClick={() => setLocation("/partida/100/ao-vivo")}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-red-500 to-red-600 text-white font-display font-bold text-lg shadow-md shadow-red-100 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
          data-testid="button-start-match"
        >
          <Play className="w-5 h-5 fill-white" />
          Iniciar Partida
        </button>
      </div>
    </div>
  );
}
