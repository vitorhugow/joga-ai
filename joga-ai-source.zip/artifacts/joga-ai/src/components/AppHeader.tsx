import { Link } from "wouter";
import { ChevronLeft, Bell, Zap } from "lucide-react";

interface AppHeaderProps {
  title?: string;
  showLogo?: boolean;
  showBack?: boolean;
  backUrl?: string;
  rightElement?: React.ReactNode;
  showBell?: boolean;
  dark?: boolean;
}

export function AppHeader({ title, showLogo, showBack, backUrl = "/", rightElement, showBell, dark }: AppHeaderProps) {
  const bg = dark ? "bg-transparent" : "bg-white/90 backdrop-blur-md border-b border-gray-100";
  const textColor = dark ? "text-white" : "text-gray-900";

  return (
    <header className={`sticky top-0 z-50 w-full flex items-center justify-between px-4 h-14 ${bg}`} data-testid="app-header">
      <div className="flex items-center flex-1">
        {showBack && (
          <Link href={backUrl} className={`mr-2 p-2 -ml-2 rounded-full ${dark ? "hover:bg-white/10" : "hover:bg-gray-100"} transition-colors`} data-testid="button-back">
            <ChevronLeft className={`w-5 h-5 ${dark ? "text-white" : "text-gray-700"}`} />
          </Link>
        )}
        {showLogo ? (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-sm shadow-primary/30">
              <Zap className="w-4 h-4 text-white fill-white" />
            </div>
            <span className="font-display font-bold text-xl text-gray-900 tracking-tight">Joga <span className="text-primary">AI</span></span>
          </div>
        ) : (
          <h1 className={`font-display font-bold text-lg ${textColor} truncate tracking-tight`} data-testid="header-title">{title}</h1>
        )}
      </div>
      <div className="flex items-center gap-2">
        {showBell && (
          <button className="relative w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center" data-testid="button-notifications">
            <Bell className="w-4 h-4 text-gray-600" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 border border-white" />
          </button>
        )}
        {rightElement && (
          <div className="flex items-center justify-end" data-testid="header-right-element">
            {rightElement}
          </div>
        )}
      </div>
    </header>
  );
}
