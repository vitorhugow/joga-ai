import { Link, useLocation } from "wouter";
import { Home, Calendar, Users, Trophy, User } from "lucide-react";

const navItems = [
  { path: "/", icon: Home, label: "Início" },
  { path: "/jogos", icon: Calendar, label: "Jogos" },
  { path: "/comunidades", icon: Users, label: "Comunidades" },
  { path: "/ranking", icon: Trophy, label: "Ranking" },
  { path: "/perfil", icon: User, label: "Perfil" },
];

export function BottomNavigation() {
  const [location] = useLocation();

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50"
      data-testid="bottom-navigation"
    >
      <div
        className="max-w-md mx-auto flex items-stretch"
        style={{
          height: 68,
          background: "rgba(255,255,255,0.97)",
          backdropFilter: "blur(24px)",
          WebkitBackdropFilter: "blur(24px)",
          boxShadow: "0 -1px 0 rgba(0,0,0,0.06), 0 -8px 24px rgba(0,0,0,0.06)",
        }}
      >
        {navItems.map((item) => {
          const isActive =
            location === item.path ||
            (item.path !== "/" && location.startsWith(item.path));
          const Icon = item.icon;

          return (
            <Link
              key={item.path}
              href={item.path}
              className="flex-1 flex flex-col items-center justify-center gap-1 py-2 group relative"
              data-testid={`nav-${item.label.toLowerCase()}`}
            >
              {/* Active indicator pill */}
              {isActive && (
                <div
                  className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-[3px] rounded-full"
                  style={{ background: "linear-gradient(90deg, #16a34a, #059669)" }}
                />
              )}

              {/* Icon container */}
              <div
                className="flex items-center justify-center w-11 h-7 rounded-xl transition-all duration-200"
                style={isActive ? { background: "rgba(22,163,74,0.1)" } : undefined}
              >
                <Icon
                  className="transition-all duration-200"
                  style={{
                    width: 20,
                    height: 20,
                    color: isActive ? "#16a34a" : "#9ca3af",
                    strokeWidth: isActive ? 2.5 : 1.8,
                    transform: isActive ? "scale(1.1)" : "scale(1)",
                  }}
                />
              </div>

              {/* Label */}
              <span
                className="font-semibold transition-colors duration-200"
                style={{
                  fontSize: 10,
                  color: isActive ? "#16a34a" : "#9ca3af",
                  fontWeight: isActive ? 800 : 600,
                  letterSpacing: isActive ? "0.02em" : "0",
                }}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
