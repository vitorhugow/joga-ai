import { useState } from "react";
import { useRoute } from "wouter";
import { Users, MapPin, Calendar, Trophy, ChevronLeft } from "lucide-react";
import { Link } from "wouter";
import { AppHeader } from "@/components/AppHeader";
import { RankingList } from "@/components/RankingList";
import { MatchCard } from "@/components/MatchCard";
import { PlayerMiniCard } from "@/components/PlayerMiniCard";
import { mockData } from "@/data/mockData";
import { calculateOverall } from "@/lib/cardUtils";

const gameTypeLabel: Record<string, string> = {
  futsal: "Futsal", fut5: "Fut 5", fut7: "Fut 7", futebol11: "Futebol 11",
};

const communityDetails: Record<string, { description: string; matchType: string }> = {
  "1": { description: "A maior comunidade de futebol de Lisboa. Jogamos todas as semanas no Parque das Nações.", matchType: "fut7" },
  "2": { description: "Futsal competitivo no Porto. Bem-vindos jogadores de todos os níveis.", matchType: "futsal" },
  "3": { description: "A comunidade mais desportiva de Lisboa. Futebol 11 no campo das Olaias.", matchType: "futebol11" },
};

const mockMembers = [
  { id: "1", name: "Diogo Ferreira", position: "AVA", overall: calculateOverall(mockData.currentPlayer.attributes) },
  ...mockData.players,
];

const rankingGolos = [
  { rank: 1, name: "Bruno Fernandes", position: "MEI", overall: 74, value: 12, valueLabel: "Golos" },
  { rank: 2, name: "Diogo Ferreira", position: "AVA", overall: calculateOverall(mockData.currentPlayer.attributes), value: 8, valueLabel: "Golos" },
  { rank: 3, name: "Rui Patricio", position: "AVA", overall: 62, value: 5, valueLabel: "Golos" },
];

const rankingOverall = [
  { rank: 1, name: "Bruno Fernandes", position: "MEI", overall: 74, value: 74, valueLabel: "Overall" },
  { rank: 2, name: "Pedro Santos", position: "MEI", overall: 70, value: 70, valueLabel: "Overall" },
  { rank: 3, name: "Miguel Costa", position: "GR", overall: 68, value: 68, valueLabel: "Overall" },
];

const rankingNotas = [
  { rank: 1, name: "Pedro Santos", position: "MEI", overall: 70, value: "8.5", valueLabel: "Média" },
  { rank: 2, name: "Bruno Fernandes", position: "MEI", overall: 74, value: "8.2", valueLabel: "Média" },
  { rank: 3, name: "Diogo Ferreira", position: "AVA", overall: calculateOverall(mockData.currentPlayer.attributes), value: "7.8", valueLabel: "Média" },
];

export default function ComunidadePage() {
  const [, params] = useRoute("/comunidades/:id");
  const [activeTab, setActiveTab] = useState<"partidas" | "rankings" | "membros">("partidas");
  const id = params?.id || "1";

  const community = mockData.communities.find((c) => c.id === id) || mockData.communities[0];
  const details = communityDetails[id] || communityDetails["1"];

  const tabs = [
    { key: "partidas", label: "Partidas" },
    { key: "rankings", label: "Rankings" },
    { key: "membros", label: "Membros" },
  ] as const;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Cover */}
      <div className="relative h-44 bg-gradient-to-br from-emerald-500 to-green-800 overflow-hidden">
        {community.coverImage && (
          <img
            src={`${community.coverImage}?w=500&h=200&fit=crop`}
            alt={community.name}
            className="w-full h-full object-cover opacity-60"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <Link href="/comunidades" className="absolute top-4 left-4 w-9 h-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center" data-testid="button-back">
          <ChevronLeft className="w-5 h-5 text-white" />
        </Link>
        <div className="absolute bottom-4 left-4 right-4">
          <h1 className="font-display font-bold text-white text-2xl leading-tight drop-shadow-md">{community.name}</h1>
          <div className="flex items-center gap-3 mt-1">
            <div className="flex items-center gap-1 text-white/80 text-xs">
              <MapPin className="w-3 h-3" />
              <span>{community.city}</span>
            </div>
            <div className="flex items-center gap-1 text-white/80 text-xs">
              <Users className="w-3 h-3" />
              <span>{community.memberCount} membros</span>
            </div>
            <span className="bg-white/20 text-white text-xs font-semibold px-2 py-0.5 rounded-full">
              {gameTypeLabel[community.gameType] || community.gameType}
            </span>
          </div>
        </div>
      </div>

      <div className="px-4 pt-4 space-y-4">
        {/* Description */}
        <p className="text-gray-600 text-sm leading-relaxed">{details.description}</p>

        {/* Join Button */}
        <button className="w-full py-3 rounded-xl bg-gradient-to-r from-primary to-emerald-600 text-white font-display font-bold text-base shadow-md active:scale-[0.98] transition-all" data-testid="button-join-community">
          Pedir para Entrar
        </button>

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-100 rounded-xl p-1">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === tab.key ? "bg-white text-gray-900 shadow-sm" : "text-gray-500"}`}
              data-testid={`tab-${tab.key}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === "partidas" && (
          <div className="space-y-3">
            {mockData.availableMatches.map((m) => (
              <MatchCard key={m.id} {...m} />
            ))}
          </div>
        )}

        {activeTab === "rankings" && (
          <div className="space-y-4">
            <RankingList title="Top Overall" entries={rankingOverall} />
            <RankingList title="Artilheiros" entries={rankingGolos} />
            <RankingList title="Melhores Notas" entries={rankingNotas} />
          </div>
        )}

        {activeTab === "membros" && (
          <div className="space-y-3">
            {mockMembers.map((m) => (
              <div key={m.id} className="bg-white rounded-xl border border-gray-100 shadow-sm px-4 py-3">
                <PlayerMiniCard name={m.name} position={m.position} overall={m.overall} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
