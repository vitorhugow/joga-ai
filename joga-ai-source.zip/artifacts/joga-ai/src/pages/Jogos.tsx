import { useState } from "react";
import { Search, SlidersHorizontal, Plus } from "lucide-react";
import { Link } from "wouter";
import { AppHeader } from "@/components/AppHeader";
import { BottomNavigation } from "@/components/BottomNavigation";
import { MatchCard } from "@/components/MatchCard";
import { mockData } from "@/data/mockData";

const allMatches = [
  ...mockData.availableMatches,
  { id: "4", title: "Pelada Dominical", city: "Lisboa", location: "Campo de Benfica", gameType: "futebol11", level: "recreativo", date: "Domingo, 09:00", spotsRemaining: "2 vagas", price: "8€" },
  { id: "5", title: "Desafio Inter-Bairros", city: "Setúbal", location: "Campo Municipal", gameType: "fut7", level: "misto", date: "Sábado, 16:00", spotsRemaining: "6 vagas", price: "Grátis" },
];

export default function Jogos() {
  const [search, setSearch] = useState("");
  const [cityFilter, setCityFilter] = useState("todas");
  const [typeFilter, setTypeFilter] = useState("todos");
  const [showFilters, setShowFilters] = useState(false);

  const cities = ["todas", "Lisboa", "Porto", "Braga", "Setúbal"];
  const cityLabels: Record<string, string> = { todas: "Todas as cidades", Lisboa: "Lisboa", Porto: "Porto", Braga: "Braga", Setúbal: "Setúbal" };
  const types = ["todos", "futsal", "fut5", "fut7", "futebol11"];
  const typeLabels: Record<string, string> = { todos: "Todos", futsal: "Futsal", fut5: "Fut 5", fut7: "Fut 7", futebol11: "Fut 11" };

  const filtered = allMatches.filter((m) => {
    const matchSearch = m.title.toLowerCase().includes(search.toLowerCase()) || m.city.toLowerCase().includes(search.toLowerCase());
    const matchCity = cityFilter === "todas" || m.city === cityFilter;
    const matchType = typeFilter === "todos" || m.gameType === typeFilter;
    return matchSearch && matchCity && matchType;
  });

  const available = filtered.filter((m) => m.spotsRemaining !== "Lotado");
  const full = filtered.filter((m) => m.spotsRemaining === "Lotado");

  return (
    <div className="min-h-screen bg-background pb-24">
      <AppHeader
        title="Jogos Disponíveis"
        rightElement={
          <Link href="/criar-partida">
            <button className="flex items-center gap-1.5 text-primary text-sm font-semibold" data-testid="button-create-match-header">
              <Plus className="w-4 h-4" />
              Criar
            </button>
          </Link>
        }
      />

      <div className="px-4 space-y-4 pt-4">
        {/* Search + Filter */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="search"
              placeholder="Pesquisar jogos..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-white border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              data-testid="input-search-matches"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2.5 rounded-xl border ${showFilters ? "bg-primary border-primary text-white" : "bg-white border-gray-200 text-gray-600"}`}
            data-testid="button-toggle-filters"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>

        {showFilters && (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 space-y-3">
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Cidade</p>
              <div className="flex flex-wrap gap-2">
                {cities.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCityFilter(c)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${cityFilter === c ? "bg-primary text-white" : "bg-gray-100 text-gray-600"}`}
                    data-testid={`filter-city-${c}`}
                  >
                    {cityLabels[c]}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Tipo de Jogo</p>
              <div className="flex flex-wrap gap-2">
                {types.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTypeFilter(t)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${typeFilter === t ? "bg-primary text-white" : "bg-gray-100 text-gray-600"}`}
                    data-testid={`filter-type-${t}`}
                  >
                    {typeLabels[t]}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {available.length > 0 && (
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">{available.length} jogo{available.length !== 1 ? "s" : ""} disponível</p>
            <div className="space-y-3">
              {available.map((m) => (
                <MatchCard key={m.id} {...m} />
              ))}
            </div>
          </div>
        )}

        {full.length > 0 && (
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">Lotados</p>
            <div className="space-y-3 opacity-60">
              {full.map((m) => (
                <MatchCard key={m.id} {...m} />
              ))}
            </div>
          </div>
        )}

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-400 text-sm">Nenhum jogo encontrado</p>
            <Link href="/criar-partida">
              <button className="mt-4 px-6 py-2.5 bg-primary text-white rounded-xl font-semibold text-sm" data-testid="button-create-first-match">
                Criar primeiro jogo
              </button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
