import { useState } from "react";
import { Share2, TrendingUp, ChevronRight, Shield } from "lucide-react";
import { Link } from "wouter";
import { PlayerCard } from "@/components/PlayerCard";
import { mockData } from "@/data/mockData";
import { calculateOverall } from "@/lib/cardUtils";

/* ─── Pitch SVG texture ─── */
const PITCH_BG = `url("data:image/svg+xml,%3Csvg width='80' height='80' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 40 L80 40' stroke='rgba(255,255,255,0.05)' stroke-width='1'/%3E%3Ccircle cx='40' cy='40' r='20' stroke='rgba(255,255,255,0.04)' stroke-width='1' fill='none'/%3E%3C/svg%3E")`;

/* ─── Data ─── */
const badges = [
  { id: "1", name: "Artilheiro",  icon: "⚽", rarity: "gold",   desc: "5 golos"         },
  { id: "2", name: "MVP",         icon: "🏆", rarity: "gold",   desc: "Melhor em campo" },
  { id: "3", name: "Fiel",        icon: "🎖️",  rarity: "silver", desc: "12 presenças"    },
  { id: "4", name: "Playmaker",   icon: "🎯", rarity: "silver", desc: "3 assists"       },
  { id: "5", name: "Regular",     icon: "📅", rarity: "bronze", desc: "10 jogos"        },
];

const pastCards = [
  { season: "2024/25", overall: 63, position: "AVA", current: true  },
  { season: "2023/24", overall: 58, position: "AVA", current: false },
  { season: "2022/23", overall: 55, position: "AVA", current: false },
];

/* ─── Stat tile ─── */
function StatTile({ icon, label, value, gradient, textColor }: {
  icon: string; label: string; value: number | string; gradient: string; textColor: string;
}) {
  return (
    <div
      className="rounded-2xl py-4 px-2 flex flex-col items-center gap-2"
      style={{ background: gradient, boxShadow: "0 2px 12px rgba(0,0,0,0.09)" }}
    >
      <div className="text-xl leading-none">{icon}</div>
      <div className="font-display font-black leading-none" style={{ fontSize: "1.75rem", color: textColor }}>{value}</div>
      <div className="text-[10px] font-black uppercase tracking-wider" style={{ color: textColor, opacity: 0.6 }}>{label}</div>
    </div>
  );
}

/* ─── Attribute bar ─── */
function AttrBar({ label, value }: { label: string; value: number }) {
  const pct = Math.min(100, value);
  const { bar, text, bg } =
    value >= 80 ? { bar: "linear-gradient(90deg, #15803d, #22c55e)", text: "#15803d", bg: "#f0fdf4" } :
    value >= 70 ? { bar: "linear-gradient(90deg, #1d4ed8, #60a5fa)", text: "#1d4ed8", bg: "#eff6ff" } :
    value >= 60 ? { bar: "linear-gradient(90deg, #b45309, #fbbf24)", text: "#b45309", bg: "#fffbeb" } :
    value >= 50 ? { bar: "linear-gradient(90deg, #c2410c, #fb923c)", text: "#c2410c", bg: "#fff7ed" } :
                  { bar: "linear-gradient(90deg, #dc2626, #f87171)", text: "#dc2626", bg: "#fef2f2" };

  return (
    <div className="flex items-center gap-3 py-0.5" data-testid={`attr-bar-${label.toLowerCase()}`}>
      <span className="text-gray-500 font-bold text-[11px] uppercase tracking-wider flex-shrink-0" style={{ width: 88 }}>{label}</span>
      <div className="flex-1 rounded-full overflow-hidden" style={{ height: 9, background: bg }}>
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: bar }} />
      </div>
      <span className="font-display font-black text-right flex-shrink-0" style={{ width: 28, fontSize: "1rem", color: text }}>{value}</span>
    </div>
  );
}

/* ─── Badge hex ─── */
function BadgeTile({ b }: { b: typeof badges[0] }) {
  const { grad, glow, label } =
    b.rarity === "gold"
      ? { grad: "linear-gradient(135deg, #fef3c7, #fbbf24, #d97706)", glow: "rgba(251,191,36,0.3)", label: "Ouro" }
      : b.rarity === "silver"
      ? { grad: "linear-gradient(135deg, #f1f5f9, #cbd5e1, #94a3b8)", glow: "rgba(148,163,184,0.3)", label: "Prata" }
      : { grad: "linear-gradient(135deg, #ffedd5, #fb923c, #ea580c)", glow: "rgba(251,146,60,0.3)", label: "Bronze" };

  return (
    <div
      className="flex flex-col items-center gap-1.5 p-2.5 rounded-2xl"
      style={{ background: "white", boxShadow: `0 3px 12px ${glow}, 0 1px 4px rgba(0,0,0,0.07)` }}
      data-testid={`badge-${b.id}`}
    >
      {/* Hexagonal icon */}
      <div
        className="flex items-center justify-center text-xl"
        style={{
          width: 44, height: 44,
          background: grad,
          clipPath: "polygon(50% 0%, 95% 25%, 95% 75%, 50% 100%, 5% 75%, 5% 25%)",
        }}
      >
        {b.icon}
      </div>
      <p className="font-black text-gray-800 text-[10px] text-center leading-tight">{b.name}</p>
      <div className="h-1 w-8 rounded-full" style={{ background: grad }} />
    </div>
  );
}

/* ─── Past card mini ─── */
function MiniEpoca({ card }: { card: typeof pastCards[0] }) {
  const accent = card.position === "DEF" ? "#60a5fa" : card.position === "MEI" ? "#c084fc" : card.position === "GR" ? "#fbbf24" : "#4ade80";
  return (
    <div className="flex flex-col items-center gap-2" data-testid={`past-card-${card.season}`}>
      <div
        className="relative rounded-xl overflow-hidden"
        style={{
          width: 68, height: 94,
          background: "linear-gradient(160deg, #031408, #052010, #0a5a1e)",
          border: card.current ? `2px solid ${accent}` : "1.5px solid rgba(255,255,255,0.08)",
          boxShadow: card.current ? `0 0 16px ${accent}55` : "0 2px 8px rgba(0,0,0,0.25)",
        }}
      >
        <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at 90% 20%, rgba(80,160,255,0.35), transparent 55%)` }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(120deg, rgba(255,140,0,0.3) 0%, transparent 45%)" }} />
        <div className="relative flex flex-col h-full p-2">
          <span className="font-display font-black leading-none" style={{ fontSize: 24, color: accent }}>{card.overall}</span>
          <span className="font-display text-[9px] font-bold" style={{ color: "rgba(255,255,255,0.45)", letterSpacing: "0.12em" }}>{card.position}</span>
          {card.current && (
            <div className="mt-auto">
              <span className="text-[7px] font-black px-1.5 py-0.5 rounded font-display" style={{ background: `${accent}25`, color: accent }}>ATUAL</span>
            </div>
          )}
        </div>
      </div>
      <p className="text-gray-400 text-[10px] font-semibold">{card.season}</p>
    </div>
  );
}

export default function Perfil() {
  const player = mockData.currentPlayer;
  const overall = calculateOverall(player.attributes);
  const [activeTab, setActiveTab] = useState<"atributos" | "estatisticas">("atributos");

  const attrs = [
    { label: "Ritmo",       value: player.attributes.ritmo },
    { label: "Finalização", value: player.attributes.finalizacao },
    { label: "Drible",      value: player.attributes.drible },
    { label: "Passe",       value: player.attributes.passe },
    { label: "Físico",      value: player.attributes.fisico },
    { label: "Defesa",      value: player.attributes.defesa },
  ];

  return (
    <div className="min-h-screen pb-28" style={{ background: "#f0f2f5" }}>

      {/* ════════════════════════════════════
          HERO — green pitch background
      ════════════════════════════════════ */}
      <div
        className="relative overflow-hidden"
        style={{ background: "linear-gradient(155deg, #020f06 0%, #042e10 28%, #0a5220 60%, #0d6826 100%)" }}
      >
        {/* Pitch texture */}
        <div className="absolute inset-0" style={{ backgroundImage: PITCH_BG, backgroundSize: "80px 80px" }} />
        {/* Radial glow */}
        <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at 50% 80%, rgba(22,163,74,0.28) 0%, transparent 65%)" }} />

        {/* Header */}
        <div className="relative flex items-center justify-between px-5 pt-5 pb-3">
          <h1 className="font-display font-black text-white text-xl tracking-tight" data-testid="header-title">
            O Meu Perfil
          </h1>
          <button
            className="flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm"
            style={{ background: "rgba(255,255,255,0.12)", border: "1px solid rgba(255,255,255,0.22)", color: "white" }}
            data-testid="button-share-card"
          >
            <Share2 className="w-3.5 h-3.5" />
            Partilhar
          </button>
        </div>

        {/* PlayerCard centered */}
        <div className="relative flex justify-center px-10 pt-2 pb-8">
          <div style={{ width: "min(265px, 100%)" }}>
            <PlayerCard
              name={player.name}
              position={player.position}
              attributes={player.attributes}
              shirtNumber={player.shirtNumber}
              title={player.title}
            />
          </div>
        </div>

        {/* White bottom curve */}
        <div className="absolute bottom-0 left-0 right-0 h-7" style={{ background: "#f0f2f5", borderRadius: "20px 20px 0 0" }} />
      </div>

      <div className="px-4 space-y-4">

        {/* ════════════════════════════════════
            PLAYER IDENTITY STRIP
        ════════════════════════════════════ */}
        <div
          className="rounded-2xl px-4 py-4 flex items-center gap-4"
          style={{ background: "white", boxShadow: "0 2px 12px rgba(0,0,0,0.08)" }}
        >
          {/* Overall badge */}
          <div
            className="w-16 h-16 rounded-2xl flex flex-col items-center justify-center flex-shrink-0"
            style={{
              background: "linear-gradient(135deg, #042e10, #16a34a)",
              boxShadow: "0 4px 16px rgba(22,163,74,0.35)",
            }}
          >
            <span className="font-display font-black text-white leading-none" style={{ fontSize: "1.75rem" }}>{overall}</span>
            <span className="font-display font-bold text-white/60 leading-none" style={{ fontSize: "0.6rem", letterSpacing: "0.15em" }}>OVR</span>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <p className="font-display font-black text-gray-900 text-xl leading-tight truncate">{player.name}</p>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full" style={{ background: "rgba(22,163,74,0.1)", color: "#16a34a" }}>
                {player.position}
              </span>
              <span className="text-[11px] font-bold text-gray-400">·</span>
              <span className="text-[12px] font-bold text-gray-600">{player.title}</span>
            </div>
            <p className="text-gray-400 text-[11px] mt-1 font-medium">Época 2024/25</p>
          </div>

          {/* Season badge */}
          <div
            className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: "linear-gradient(135deg, #fef3c7, #fbbf24)" }}
          >
            <span className="text-lg">🌟</span>
          </div>
        </div>

        {/* ════════════════════════════════════
            STATS — 4 premium tiles
        ════════════════════════════════════ */}
        <div className="grid grid-cols-4 gap-2.5">
          <StatTile icon="📅" label="Jogos"   value={player.seasonStats.matches} gradient="linear-gradient(160deg, #f8fafc, #e2e8f0)" textColor="#475569" />
          <StatTile icon="⚽" label="Golos"   value={player.seasonStats.goals}   gradient="linear-gradient(160deg, #f0fdf4, #dcfce7)" textColor="#16a34a" />
          <StatTile icon="🎯" label="Assist." value={player.seasonStats.assists} gradient="linear-gradient(160deg, #eff6ff, #dbeafe)" textColor="#1d4ed8" />
          <StatTile icon="🏆" label="MVP"     value={player.seasonStats.mvp}     gradient="linear-gradient(160deg, #fffbeb, #fef3c7)" textColor="#b45309" />
        </div>

        {/* ════════════════════════════════════
            ATRIBUTOS + ESTATÍSTICAS tabs
        ════════════════════════════════════ */}
        <div className="bg-white rounded-2xl overflow-hidden" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.07)" }}>
          {/* Tab bar */}
          <div className="flex" style={{ borderBottom: "1px solid #f1f5f9" }}>
            {(["atributos", "estatisticas"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setActiveTab(t)}
                className="flex-1 py-3.5 text-sm font-bold transition-colors relative"
                style={{ color: activeTab === t ? "#16a34a" : "#9ca3af" }}
                data-testid={`tab-${t}`}
              >
                {t === "atributos" ? "Atributos" : "Estatísticas"}
                {activeTab === t && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ background: "linear-gradient(90deg, transparent, #16a34a, transparent)" }} />
                )}
              </button>
            ))}
          </div>

          {activeTab === "atributos" && (
            <div className="px-4 py-5">
              {/* Overall summary row */}
              <div className="flex items-center justify-between mb-5 pb-4" style={{ borderBottom: "1px solid #f1f5f9" }}>
                <div>
                  <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">Overall</p>
                  <p className="font-display font-black text-gray-900" style={{ fontSize: "2.5rem", lineHeight: 1 }}>{overall}</p>
                </div>
                <div
                  className="flex items-center gap-2 px-4 py-2 rounded-xl font-semibold text-sm"
                  style={{ background: "linear-gradient(135deg, #f0fdf4, #dcfce7)", color: "#16a34a" }}
                >
                  <TrendingUp className="w-4 h-4" />
                  +3 esta época
                </div>
              </div>
              {/* Bars */}
              <div className="space-y-3">
                {attrs.map((a) => <AttrBar key={a.label} label={a.label} value={a.value} />)}
              </div>
              <div className="flex items-center justify-between mt-5 pt-4 text-[11px]" style={{ borderTop: "1px solid #f1f5f9" }}>
                <span className="text-gray-400 font-medium">Próxima evolução</span>
                <span className="text-primary font-bold">Joga mais 2 partidas →</span>
              </div>
            </div>
          )}

          {activeTab === "estatisticas" && (
            <div className="px-4 py-4">
              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: "⭐", label: "Média/Jogo",  v: "7.4"  },
                  { icon: "📅", label: "Presenças",   v: "12/14"},
                  { icon: "🏅", label: "Melhor nota", v: "9.5"  },
                  { icon: "🏆", label: "MVPs",        v: String(player.seasonStats.mvp) },
                  { icon: "🎯", label: "Hat-tricks",  v: "1"    },
                  { icon: "⚠️", label: "Faltas",      v: "6"    },
                ].map((s) => (
                  <div key={s.label} className="rounded-xl p-3 flex flex-col items-center gap-1.5 text-center" style={{ background: "#f8fafc" }}>
                    <span className="text-xl">{s.icon}</span>
                    <p className="font-display font-black text-gray-900 text-xl leading-none">{s.v}</p>
                    <p className="text-gray-400 text-[9px] font-bold uppercase tracking-wide leading-tight">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* ════════════════════════════════════
            DISTINTIVOS
        ════════════════════════════════════ */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-display font-black text-gray-900 text-lg">Distintivos</h2>
            <span className="text-xs font-bold text-gray-400 bg-gray-100 px-2.5 py-1 rounded-full">{badges.length} desbloqueados</span>
          </div>
          <div className="grid grid-cols-5 gap-2">
            {badges.map((b) => <BadgeTile key={b.id} b={b} />)}
          </div>
        </div>

        {/* ════════════════════════════════════
            ÉPOCAS ANTERIORES
        ════════════════════════════════════ */}
        <div>
          <h2 className="font-display font-black text-gray-900 text-lg mb-3">Épocas</h2>
          <div className="flex gap-4 overflow-x-auto pb-1">
            {pastCards.map((card) => <MiniEpoca key={card.season} card={card} />)}
          </div>
        </div>

        {/* ════════════════════════════════════
            COMUNIDADES
        ════════════════════════════════════ */}
        <div>
          <h2 className="font-display font-black text-gray-900 text-lg mb-3">Comunidades</h2>
          <div className="flex gap-2.5 overflow-x-auto pb-1">
            {mockData.communities.slice(0, 3).map((c) => (
              <Link key={c.id} href={`/comunidades/${c.id}`}>
                <div
                  className="flex-shrink-0 flex items-center gap-2.5 rounded-xl px-3.5 py-3 active:scale-95 transition-transform"
                  style={{ background: "white", boxShadow: "0 2px 8px rgba(0,0,0,0.07)" }}
                  data-testid={`community-tag-${c.id}`}
                >
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "linear-gradient(135deg, #16a34a, #047857)" }}
                  >
                    <span className="font-display font-black text-white text-sm">{c.name[0]}</span>
                  </div>
                  <div>
                    <p className="text-gray-900 text-xs font-bold truncate max-w-[90px]">{c.name}</p>
                    <p className="text-gray-400 text-[10px] font-medium">{c.memberCount} membros</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* ════════════════════════════════════
            CTA — Ver Evolução
        ════════════════════════════════════ */}
        <Link href="/partida/100/pos-jogo">
          <div
            className="w-full rounded-2xl py-4.5 flex items-center justify-center gap-3 active:scale-[0.98] transition-all"
            style={{
              background: "linear-gradient(135deg, #052e10 0%, #16a34a 50%, #15803d 100%)",
              boxShadow: "0 6px 24px rgba(22,163,74,0.38), 0 2px 8px rgba(0,0,0,0.2)",
              paddingTop: "1.1rem",
              paddingBottom: "1.1rem",
            }}
            data-testid="button-go-evolution"
          >
            <Shield className="w-5 h-5 text-white/70" />
            <span className="font-display font-black text-white text-lg tracking-tight">Ver Evolução</span>
            <ChevronRight className="w-5 h-5 text-white/50" />
          </div>
        </Link>

      </div>
    </div>
  );
}
