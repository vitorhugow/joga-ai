import { Crown, Sparkles, Share2, BarChart3, Star, Shield } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNavigation } from "@/components/BottomNavigation";
import { PremiumCard } from "@/components/PremiumCard";
import { SectionHeader } from "@/components/SectionHeader";

const benefits = [
  { icon: Star, label: "Cartas Premium", desc: "Skins exclusivas para a tua carta de jogador" },
  { icon: Share2, label: "Exportar para Story", desc: "Partilha a tua carta no Instagram com estilo" },
  { icon: BarChart3, label: "Estatísticas Avançadas", desc: "Análise detalhada do teu desempenho" },
  { icon: Crown, label: "Perfil em Destaque", desc: "Aparece em primeiro nos rankings e buscas" },
  { icon: Shield, label: "Prioridade em Jogos", desc: "Garantia de vaga nos jogos públicos" },
  { icon: Sparkles, label: "Título Personalizado", desc: '"Matador", "Maestro", "Muralha" e mais' },
];

const premiumSkins = [
  { label: "Ouro", gradient: "from-amber-400 via-yellow-300 to-amber-500", border: "border-amber-300" },
  { label: "Platina", gradient: "from-slate-300 via-white to-slate-400", border: "border-slate-300" },
  { label: "Diamante", gradient: "from-blue-300 via-cyan-200 to-blue-400", border: "border-blue-200" },
  { label: "Élite", gradient: "from-purple-500 via-fuchsia-400 to-purple-600", border: "border-purple-300" },
];

export default function Premium() {
  return (
    <div className="min-h-screen bg-background pb-24">
      <AppHeader title="Premium" />

      <div className="px-4 space-y-6 pt-4">
        {/* Hero */}
        <div className="relative bg-gradient-to-br from-slate-800 to-slate-950 rounded-3xl overflow-hidden px-6 py-8 text-center">
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: "repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%)",
            backgroundSize: "20px 20px"
          }} />
          <Crown className="w-10 h-10 text-amber-400 mx-auto mb-3" />
          <h2 className="font-display font-black text-white text-2xl mb-2">Joga AI Premium</h2>
          <p className="text-white/60 text-sm leading-relaxed max-w-xs mx-auto">
            Visual, estatístico e de status. Não podes pagar para evoluir — a carta é tua.
          </p>
        </div>

        {/* Skins Preview */}
        <div>
          <SectionHeader title="Cartas Premium" className="mb-3" />
          <div className="flex gap-3 overflow-x-auto pb-1 -mx-4 px-4">
            {premiumSkins.map((skin) => (
              <div
                key={skin.label}
                className={`flex-shrink-0 w-28 h-36 rounded-2xl bg-gradient-to-br ${skin.gradient} border ${skin.border} shadow-md flex flex-col items-center justify-center gap-1 relative overflow-hidden`}
                data-testid={`skin-preview-${skin.label.toLowerCase()}`}
              >
                <div className="absolute inset-0 opacity-10 pitch-texture" />
                <span className="font-display font-black text-4xl text-white/90 drop-shadow-md relative">76</span>
                <span className="font-display text-xs text-white/70 relative uppercase tracking-widest">AVA</span>
                <div className="mt-1 px-2 py-0.5 bg-white/20 rounded-full relative">
                  <span className="text-white text-[9px] font-bold">{skin.label}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits Grid */}
        <div>
          <SectionHeader title="Benefícios" className="mb-3" />
          <div className="grid grid-cols-2 gap-3">
            {benefits.map((b) => {
              const Icon = b.icon;
              return (
                <div key={b.label} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex flex-col gap-2" data-testid={`benefit-${b.label.toLowerCase().replace(/\s+/g, "-")}`}>
                  <div className="w-8 h-8 rounded-xl bg-amber-50 flex items-center justify-center">
                    <Icon className="w-4 h-4 text-amber-600" />
                  </div>
                  <p className="font-display font-bold text-gray-900 text-sm leading-tight">{b.label}</p>
                  <p className="text-gray-400 text-[11px] leading-snug">{b.desc}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Plans */}
        <div className="space-y-3">
          <SectionHeader title="Escolhe o Teu Plano" className="mb-3" />
          <PremiumCard
            title="Premium Anual"
            price="39,99€"
            period="ano"
            badge="Melhor Valor"
            highlighted
            features={[
              "Cartas premium exclusivas",
              "Exportar carta para Instagram",
              "Estatísticas avançadas completas",
              "Perfil em destaque nos rankings",
              "Prioridade em jogos públicos",
              "Título personalizado na carta",
              "Histórico completo de épocas",
              "Top momentos da temporada",
              "Badges premium exclusivos",
              "Carta especial no fim da época",
            ]}
          />
          <PremiumCard
            title="Premium Mensal"
            price="4,99€"
            period="mês"
            features={[
              "Cartas premium exclusivas",
              "Exportar carta para Instagram",
              "Estatísticas avançadas",
              "Perfil em destaque",
              "Prioridade em jogos públicos",
            ]}
          />
        </div>

        {/* Disclaimer */}
        <div className="text-center pb-4">
          <p className="text-gray-400 text-xs leading-relaxed">
            O Premium não é pay-to-win. Não compras evolução — a tua carta evolui pelo teu desempenho real nos jogos.
          </p>
        </div>
      </div>
    </div>
  );
}
