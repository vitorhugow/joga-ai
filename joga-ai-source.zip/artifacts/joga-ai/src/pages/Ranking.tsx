import { useState } from "react";
import { Trophy, TrendingUp, Target, Shield, Star } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { PlayerBadge } from "@/components/PlayerBadge";
import { mockData } from "@/data/mockData";
import { calculateOverall } from "@/lib/cardUtils";

const myOverall = calculateOverall(mockData.currentPlayer.attributes);

const rankingData = {
  overall: [
    { rank: 1, name: "Bruno Fernandes", position: "MEI", overall: 74, value: 74, valueLabel: "OVR" },
    { rank: 2, name: "Pedro Santos", position: "MEI", overall: 70, value: 70, valueLabel: "OVR" },
    { rank: 3, name: "Miguel Costa", position: "GR", overall: 68, value: 68, valueLabel: "OVR" },
    { rank: 4, name: "João Silva", position: "DEF", overall: 65, value: 65, valueLabel: "OVR" },
    { rank: 5, name: "Diogo Ferreira", position: "AVA", overall: myOverall, value: myOverall, valueLabel: "OVR", isMe: true },
    { rank: 6, name: "Rui Patricio", position: "AVA", overall: 62, value: 62, valueLabel: "OVR" },
  ],
  golos: [
    { rank: 1, name: "Bruno Fernandes", position: "MEI", overall: 74, value: 14, valueLabel: "Golos" },
    { rank: 2, name: "Rui Patricio", position: "AVA", overall: 62, value: 11, valueLabel: "Golos" },
    { rank: 3, name: "Diogo Ferreira", position: "AVA", overall: myOverall, value: 8, valueLabel: "Golos", isMe: true },
    { rank: 4, name: "Pedro Santos", position: "MEI", overall: 70, value: 7, valueLabel: "Golos" },
    { rank: 5, name: "João Silva", position: "DEF", overall: 65, value: 3, valueLabel: "Golos" },
  ],
  assistencias: [
    { rank: 1, name: "Pedro Santos", position: "MEI", overall: 70, value: 12, valueLabel: "Assist." },
    { rank: 2, name: "Bruno Fernandes", position: "MEI", overall: 74, value: 10, valueLabel: "Assist." },
    { rank: 3, name: "Diogo Ferreira", position: "AVA", overall: myOverall, value: 4, valueLabel: "Assist.", isMe: true },
    { rank: 4, name: "João Silva", position: "DEF", overall: 65, value: 3, valueLabel: "Assist." },
    { rank: 5, name: "Miguel Costa", position: "GR", overall: 68, value: 1, valueLabel: "Assist." },
  ],
  notas: [
    { rank: 1, name: "Pedro Santos", position: "MEI", overall: 70, value: "8.7", valueLabel: "Média" },
    { rank: 2, name: "Bruno Fernandes", position: "MEI", overall: 74, value: "8.4", valueLabel: "Média" },
    { rank: 3, name: "Diogo Ferreira", position: "AVA", overall: myOverall, value: "8.0", valueLabel: "Média", isMe: true },
    { rank: 4, name: "Miguel Costa", position: "GR", overall: 68, value: "7.6", valueLabel: "Média" },
    { rank: 5, name: "João Silva", position: "DEF", overall: 65, value: "7.1", valueLabel: "Média" },
  ],
};

type Category = "overall" | "golos" | "assistencias" | "notas";

const categories: { key: Category; label: string; icon: typeof Trophy }[] = [
  { key: "overall", label: "Overall", icon: Star },
  { key: "golos", label: "Golos", icon: Target },
  { key: "assistencias", label: "Assist.", icon: TrendingUp },
  { key: "notas", label: "Notas", icon: Star },
];

const rankMedal = ["🥇", "🥈", "🥉"];

export default function Ranking() {
  const [category, setCategory] = useState<Category>("overall");
  const entries = rankingData[category];

  return (
    <div className="min-h-screen bg-[#f2f4f7] pb-24">
      <AppHeader title="Ranking Global" />

      <div className="px-4 pt-4 space-y-5">
        {/* Podium */}
        <div className="bg-gradient-to-br from-slate-800 to-slate-950 rounded-2xl p-4 overflow-hidden relative">
          <div className="absolute inset-0 opacity-5"
            style={{ backgroundImage: "repeating-linear-gradient(45deg, rgba(255,255,255,0.5) 0, rgba(255,255,255,0.5) 1px, transparent 0, transparent 50%)", backgroundSize: "16px 16px" }}
          />
          <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-3 relative">Top 3 · {categories.find(c => c.key === category)?.label}</p>
          <div className="flex items-end justify-center gap-3 relative">
            {/* 2nd */}
            {entries[1] && (
              <div className="flex flex-col items-center gap-1 mb-0">
                <PlayerBadge overall={entries[1].overall} position={entries[1].position} size="sm" />
                <p className="text-white/70 text-[10px] font-semibold text-center max-w-[60px] truncate leading-tight">{entries[1].name.split(" ")[0]}</p>
                <div className="bg-slate-600 rounded-lg flex items-center justify-center w-16 h-10">
                  <span className="text-2xl">🥈</span>
                </div>
              </div>
            )}
            {/* 1st */}
            {entries[0] && (
              <div className="flex flex-col items-center gap-1 -mb-0.5">
                <div className="relative">
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-lg">👑</span>
                  <PlayerBadge overall={entries[0].overall} position={entries[0].position} size="md" />
                </div>
                <p className="text-white font-bold text-[11px] text-center max-w-[70px] truncate leading-tight">{entries[0].name.split(" ")[0]}</p>
                <div className="bg-amber-500/80 rounded-lg flex items-center justify-center w-20 h-14">
                  <span className="text-3xl">🥇</span>
                </div>
              </div>
            )}
            {/* 3rd */}
            {entries[2] && (
              <div className="flex flex-col items-center gap-1 mb-2">
                <PlayerBadge overall={entries[2].overall} position={entries[2].position} size="sm" />
                <p className="text-white/70 text-[10px] font-semibold text-center max-w-[60px] truncate leading-tight">{entries[2].name.split(" ")[0]}</p>
                <div className="bg-slate-700 rounded-lg flex items-center justify-center w-14 h-7">
                  <span className="text-lg">🥉</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Category tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {categories.map((c) => {
            const Icon = c.icon;
            return (
              <button
                key={c.key}
                onClick={() => setCategory(c.key)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold transition-all ${category === c.key ? "bg-primary text-white shadow-sm shadow-primary/20" : "bg-white text-gray-600 border border-gray-200"}`}
                data-testid={`ranking-tab-${c.key}`}
              >
                <Icon className="w-3.5 h-3.5" />
                {c.label}
              </button>
            );
          })}
        </div>

        {/* Full list */}
        <div className="space-y-2">
          {entries.map((entry, idx) => (
            <div
              key={entry.rank}
              className={`flex items-center gap-3 px-4 py-3 rounded-2xl border shadow-sm ${entry.isMe ? "bg-primary/5 border-primary/20" : "bg-white border-gray-100"}`}
              data-testid={`ranking-entry-${entry.rank}`}
            >
              <div className="w-8 text-center flex-shrink-0">
                {idx < 3 ? (
                  <span className="text-xl">{rankMedal[idx]}</span>
                ) : (
                  <span className="font-display font-bold text-gray-400 text-lg">{entry.rank}</span>
                )}
              </div>
              <PlayerBadge overall={entry.overall} position={entry.position} size="sm" />
              <div className="flex-1 min-w-0">
                <p className={`font-semibold text-sm truncate ${entry.isMe ? "text-primary" : "text-gray-900"}`}>
                  {entry.isMe ? `${entry.name} (Tu)` : entry.name}
                </p>
                <p className="text-xs text-gray-400">{entry.position}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="font-display font-black text-gray-900 text-xl leading-none">{entry.value}</p>
                <p className="text-[10px] text-gray-400 uppercase tracking-wider">{entry.valueLabel}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
